# Bastidores da edição (só para você, Claude; a pessoa nunca vê isto)

As ferramentas prontas ficam na pasta `scripts/` desta skill (o caminho da skill aparece quando ela é
carregada). Use sempre elas: são as mesmas etapas do sistema da Bruna, testadas. Rode no terminal que
estiver disponível (PowerShell ou Bash), com os caminhos completos entre aspas. Nos exemplos abaixo,
`PY` é o Python das ferramentas (seção 1) e `<skill>` é a pasta desta skill.

## 1. Ferramentas (confira uma vez; instale avisando antes)

**Qual Python usar (`PY`).** Se a Construtora já fez o check-up, o caminho está anotado no
`meu-sistema/progresso.md` (em geral `meu-sistema/.ferramentas/Scripts/python.exe` no Windows e
`meu-sistema/.ferramentas/bin/python` no Mac): use esse. Se não, crie o mesmo ambiente
(`py -m venv "<meu-sistema>\.ferramentas"` no Windows, `python3 -m venv "<meu-sistema>/.ferramentas"` no
Mac; sem o sistema da Construtora, uma pasta `ferramentas-video` na pasta de trabalho) e anote o
caminho no progresso. No Mac, instalar pacote fora desse ambiente costuma ser recusado: use sempre ele.

**Confira:**
```
PY --version
PY -c "import faster_whisper, PIL, numpy; print('ok')"
ffmpeg -version          (se não achar, as ferramentas usam o plano B, imageio-ffmpeg)
```

Se faltar algo, avise em português de gente ("vou preparar umas ferramentas aqui nos bastidores; podem
aparecer janelas pedindo permissão ou a senha do computador, é só aceitar; só na primeira vez") e instale:

| Para quê | Windows | Mac |
|---|---|---|
| Python 3 (roda as ferramentas) | `winget install -e --id Python.Python.3.12 --scope user` | `brew install python` (ou o instalador do python.org) |
| Cortar, converter e montar vídeo | `winget install -e --id Gyan.FFmpeg` | `brew install ffmpeg` |
| Tudo o que roda no Python, de uma vez | `PY -m pip install --upgrade faster-whisper pillow pillow-heif numpy yt-dlp imageio-ffmpeg` | igual |
| Recortar a pessoa (só se ela pedir coisa atrás dela) | `PY -m pip install rembg opencv-python-headless` | igual |

O que cada pacote faz: `faster-whisper` ouve a fala e anota o tempo de cada palavra; `pillow`,
`pillow-heif` e `numpy` desenham título, capa e sons e leem foto de iPhone; `yt-dlp` baixa referência
por link; `imageio-ffmpeg` é o plano B da ferramenta de vídeo, sem senha de administrador.

Depois de instalar pelo winget, o terminal precisa ser reaberto. As ferramentas desta skill acham a de
vídeo sozinhas, mesmo fora do caminho padrão. Na primeira vez que ouvir um vídeo, a ferramenta baixa o
"dicionário de fala" (uns 500 MB no `small`): avise que a primeira vez demora.

## 2. As ferramentas desta skill (`scripts/`)

| Ferramenta | O que faz |
|---|---|
| `respiros.py` | TRANSCREVE a fala palavra por palavra e tira TODOS os respiros: silêncio do começo e do fim e toda pausa entre frases, olhando a fala (funciona até com barulho de fundo). Já deixa em pé (1080x1920). Com `--so-texto`, só transcreve, sem cortar (para referência). |
| `cortar.py` | Tira trechos escolhidos (erro de fala, frase repetida) e ajusta os tempos do texto. |
| `legendas.py` | Legenda na tela no padrão da pessoa (fonte, cores, palavra-chave em destaque, palavra por palavra ou em blocos). Grava também o `texto.txt` final do vídeo. |
| `pecas.py` | Título, cartela, número em destaque, logo e capa, nas cores e fontes dela. |
| `sons.py` | Sons leves próprios, sem direito autoral: whoosh, pop, ding, swish. |
| `montar.py` | Junta tudo: zoom parado, preto e branco em trechos, cor, peças, legenda, sons e música. Tem o modo `--teste 20`. |
| `conferir.py` | Grade de quadros para conferir, os 4 quadros do teste de 20 s, folha para escolher capa e quadro solto. |

Cada uma explica o uso se rodar sem argumentos. Tempos medidos num notebook comum, com vídeo 4K de
iPhone: transcrever e tirar os respiros de 30 s levou uns 2 minutos; o teste de 20 s montado, pouco mais
de 1 minuto. Na primeira vez soma o download do dicionário de fala.

## 3. As pastas

```
meu-sistema/
  minha-edicao/                 o padrão aprovado (fica igual de um vídeo para o outro)
    legenda.json                o padrão da legenda (formato no topo do legendas.py)
    pecas-base.json             fontes e cores das peças (formato no topo do pecas.py, sem a lista "pecas")
    fontes/                     os .ttf da marca
    sons/                       os sons do sons.py, gerados uma vez
  minha-edicao.md               cópia da assinatura (backup)
  videos-de-referencia/         as referências que ela mandou
  videos-oficina/<data>-<tema>/ uma pasta de trabalho por vídeo
```

Sem o sistema da Construtora, crie as mesmas pastas numa pasta `edicao` ao lado do vídeo.

Para cada vídeo: crie a oficina, copie para lá o vídeo cru e a pasta `fontes/` do padrão. Rode
`montar.py` sempre com o plano dentro da oficina e caminhos curtos, relativos a ela (a legenda não aceita
caminho completo do Windows).

## 4. O passo a passo de TODO vídeo

1. **Transcrever e tirar os respiros, sempre, sem a pessoa pedir:**
   `PY "<skill>/scripts/respiros.py" bruto.mov . --ritmo normal --vocabulario "<palavras do dicionário da assinatura>"`
   O ritmo vem da assinatura (calmo deixa respiro de fim de frase; rapido corta seco). O vocabulário
   ajuda a ferramenta a escrever certo nome, marca e termo em inglês. Vídeo de iPhone lavado: `--hdr`.
   Vídeo que veio deitado: a ferramenta corta as laterais; confira se o rosto ficou no quadro.
2. **Erro de fala:** leia o texto que a ferramenta mostrou. Frase dita duas vezes, começo abandonado,
   "não, pera, de novo": corte a tentativa ruim e fique com a ÚLTIMA versão, com `cortar.py` (do t0 da
   primeira palavra ruim até o t0 da primeira palavra que vale). Quando for óbvio, corte sozinho e conte
   na entrega o que tirou. Na dúvida, pergunte.
3. **Corrija o texto** no `03-transcricao.json` (ou no da saída do cortar): nome próprio, marca, termo
   em inglês ("cloud" no lugar de Claude). Troque só a palavra, mantenha `t0` e `t1`. Anote as trocas
   novas no dicionário da assinatura.
4. **O plano**, a partir da assinatura: título (2 a 3 s), palavras-chave da legenda (1 a cada 2 ou 3
   blocos), peças (número quando ela fala um número, cartela de resumo), zoom (no máximo 3 ou 4, fechando
   na frase forte e segurando), preto e branco (se a assinatura usa), sons (whoosh na abertura, pop quando
   entra texto, nada barulhento), cor e música.
5. **Monte as peças:** `pecas.py` (título, número, cartela, logo; junte o `pecas-base.json` com a lista
   de peças deste vídeo) e `legendas.py` (com o `legenda.json` e os destaques deste vídeo; ele grava o
   `texto.txt` final). Os sons: `sons.py` uma vez só, em `minha-edicao/sons/`.
6. **Teste de 20 segundos** (padrão novo ou ainda não aprovado): `montar.py plano.json --teste 20`, depois
   `conferir.py teste REEL-teste.mp4`. Olhe os 4 quadros você mesmo e mostre para ela. Aprovou? Siga.
7. **O vídeo inteiro:** `montar.py plano.json`, depois `conferir.py grade REEL.mp4 03-cortado.mp4` e
   olhe a grade (seção 7). Gravar leva de 1 a 3 vezes a duração do vídeo: avise e não fique esperando
   com ela.
8. **A capa:** `conferir.py contato 03-cortado.mp4`, escolha 3 ou 4 quadros com olhar na câmera, boca
   fechada e mão fora do rosto, tire com `conferir.py quadro`, monte com `pecas.py` (tipo `capa`) e mostre
   as opções com a sua aposta. A capa não troca depois de publicado.
9. **Entregue:** com esteira, o pronto vai para `2 - REELS PRONTOS` e a capa para `3 - CAPAS`, e o cru
   para `1 - VÍDEOS CRUS/já editados`; sem esteira, numa pasta `prontos` ao lado do cru. Diga onde está
   e ofereça abrir. Conte em uma linha o que saiu (segundos de pausa, frase repetida).

## 5. A marca e as fontes

**A marca é uma só no sistema.** Antes de perguntar, leia a seção `## Marca` do
`meu-sistema/perfil.md`. Se existe, use e só confirme. Se não existe, pergunte (item 6 da "Primeira vez"
no SKILL.md) e, depois do ok dela, salve assim, porque o carrossel e o painel leem daqui:

```
## Marca
- Cores: principal #______, apoio #______, destaque #______, fundo #______, texto #______
- Fontes (Google Fonts): títulos ______, texto ______
- Logo: meu-sistema/marca/logo.png (ou "sem logo")
- Vibe: moderna | clássica | divertida
- De onde veio: manual | site | feed | escolhida das opções
```

**Fontes:** baixe os `.ttf` do Google Fonts (repositório github.com/google/fonts, pasta `ofl/<nome>`)
para `minha-edicao/fontes/`. A legenda usa o NOME DA FAMÍLIA; descubra com
`PY -c "from PIL import ImageFont; print(ImageFont.truetype(r'fontes/ARQUIVO.ttf').getname())"`.
As peças usam o caminho do arquivo. Sem marca definida: Montserrat ExtraBold na legenda e Anton no título.
Se a legenda sair numa fonte comum do sistema, o nome da família ou o `fontes_dir` está errado: refaça.

## 6. Receitas extras

- **Baixar referência por link:** `PY -m yt_dlp -o "videos-de-referencia/%(id)s.%(ext)s" "LINK"`. Nunca
  use a conta logada da pessoa. Se pedir login, peça para ela salvar o vídeo e mandar o arquivo.
- **Estudar referência:** `conferir.py contato ref.mp4` para ver o visual (posição e estilo da legenda,
  título, cores, cortes, zoom, filtro) e `respiros.py ref.mp4 <pasta> --so-texto` para ler o texto e o
  ritmo da fala, sem cortar nada. Leve o mecanismo, nunca as frases nem a marca de outra pessoa.
- **Coisa atrás da pessoa** (print, gráfico subindo atrás dela): gere a máscara dela quadro a quadro com
  rembg (modelo `u2net_human_seg`, em 540x960, borda suavizada), e monte em camadas: vídeo, a imagem por
  cima, e a pessoa recortada por cima da imagem (`alphamerge` com a máscara). É pesado: teste em 5
  segundos e avise que demora.
- **Música:** só se ela pedir, sempre baixinha (`volume` 0.08 a 0.12 no plano).
- **Vídeo sem fala** (só música e imagens): não use o `respiros.py`; corte os trechos parados com
  `cortar.py` a partir da folha de contato.

## 7. Conferir antes de mostrar

- Duração do REEL igual à do `03-cortado` (diferença de até 0,3 s).
- Nenhum respiro sobrando: na grade e no texto, nada de pausa longa, começo ou fim parado.
- Legenda batendo com a fala, palavras certas, zero travessão.
- Nada que precisa ser lido fora da área segura: x de 60 a 900, y de 250 a 1470 (longe do rodapé e da
  coluna da direita, onde ficam os botões do Instagram).
- Zoom sem vaivém; título fora do rosto; o número entra quando ela fala o número.
- Fontes certas e cores da marca.

## 8. Quando não dá para editar aqui

Se a máquina não deixa (sem permissão para instalar, sem acesso às ferramentas), entregue o roteiro
para o CapCut: `references/roteiro-capcut.md`.
