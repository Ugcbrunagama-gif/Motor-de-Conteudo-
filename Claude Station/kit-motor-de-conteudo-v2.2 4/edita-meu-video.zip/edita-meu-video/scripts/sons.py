# -*- coding: utf-8 -*-
"""Gera sons leves para o vídeo (feitos aqui, sem direito autoral): whoosh, pop, ding, swish.

uso: python sons.py PASTA_DE_SAIDA
"""
import os
import sys
import wave

import numpy as np

saida = sys.argv[1] if len(sys.argv) > 1 else "sons"
os.makedirs(saida, exist_ok=True)
SR = 44100


def salvar(nome, sinal):
    sinal = np.clip(sinal, -1, 1)
    d = (sinal * 32767).astype(np.int16)
    estereo = np.empty(len(d) * 2, dtype=np.int16)
    estereo[0::2] = d
    estereo[1::2] = d
    with wave.open(os.path.join(saida, nome), "w") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(estereo.tobytes())
    print("ok", os.path.join(saida, nome))


def tempo(seg):
    return np.arange(int(SR * seg)) / SR


rng = np.random.default_rng(7)

# WHOOSH: ar subindo e descendo (abertura, entrada de título)
tt = tempo(0.55)
ruido = rng.standard_normal(len(tt))
for k in (6, 12, 24):
    ruido = np.convolve(ruido, np.ones(k) / k, mode="same")
env = np.sin(np.pi * np.linspace(0, 1, len(tt))) ** 1.6
salvar("whoosh.wav", ruido / np.abs(ruido).max() * env * 0.55)

# POP: bolha suave (texto entrando)
tt = tempo(0.12)
f = 520 * np.exp(-tt * 8) + 180
salvar("pop.wav", np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 32) * 0.7)

# DING: sininho macio (número, conquista)
tt = tempo(0.7)
salvar("ding.wav", (np.sin(2 * np.pi * 1174.7 * tt) * 0.6 + np.sin(2 * np.pi * 1760 * tt) * 0.35) * np.exp(-tt * 6.5) * 0.5)

# SWISH: ar curto (troca de assunto)
tt = tempo(0.25)
ruido = np.convolve(rng.standard_normal(len(tt)), np.ones(24) / 24, mode="same")
salvar("swish.wav", ruido / np.abs(ruido).max() * np.sin(np.pi * np.linspace(0, 1, len(tt))) ** 2 * 0.5)
