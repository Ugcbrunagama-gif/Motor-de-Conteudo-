# -*- coding: utf-8 -*-
"""Tira TODOS os respiros do vídeo cru, automaticamente, e já deixa em pé (1080x1920).

uso: python respiros.py BRUTO.mov PASTA_DA_OFICINA [--ritmo calmo|normal|rapido] [--modelo small|medium]
                        [--vocabulario "nomes, termos, marcas"] [--hdr] [--so-texto]

Como funciona (em uma passada só pelo vídeo, para ser rápido):
  1. Separa o áudio e ouve, anotando o tempo de cada palavra.
  2. Decide os cortes pela FALA: silêncio do começo e do fim e toda pausa entre frases acima do
     limite do ritmo. Pega pausa até em sala com barulho de fundo, porque olha a fala, não o volume.
  3. Grava o vídeo já cortado, em pé, 30 quadros            -> 03-cortado.mp4
  4. Ajusta os tempos das palavras ao vídeo cortado           -> 03-transcricao.json
No fim mostra o texto falado: procure frase repetida ou começo errado e corte com cortar.py.

Ritmo: calmo deixa respiro de fim de frase; rapido corta seco. O padrão é normal.
--so-texto: só transcreve, sem cortar (para estudar vídeo de referência) -> texto.txt
"""
import argparse
import os
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _comum import duracao, ffmpeg, remapear, rodar, salvar_transcricao  # noqa: E402

RITMOS = {
    #         pausa máxima entre palavras, folga em volta da fala
    "calmo":  (0.60, 0.18),
    "normal": (0.42, 0.12),
    "rapido": (0.28, 0.08),
}

ap = argparse.ArgumentParser()
ap.add_argument("bruto")
ap.add_argument("oficina")
ap.add_argument("--ritmo", default="normal", choices=list(RITMOS))
ap.add_argument("--modelo", default="small", help="small (rápido) ou medium (erra menos, mais lento)")
ap.add_argument("--vocabulario", default="", help="nomes e termos que ela fala, para escrever certo")
ap.add_argument("--hdr", action="store_true", help="vídeo de iPhone em HDR (fica lavado)")
ap.add_argument("--so-texto", action="store_true", help="só transcreve, sem cortar (vídeo de referência)")
args = ap.parse_args()

os.makedirs(args.oficina, exist_ok=True)
wav = os.path.join(args.oficina, "00-audio.wav")
fim = os.path.join(args.oficina, "03-cortado.mp4")
tr0 = os.path.join(args.oficina, "02-transcricao-bruto.json")
tr3 = os.path.join(args.oficina, "03-transcricao.json")
pausa_max, folga = RITMOS[args.ritmo]

# 1. áudio e transcrição
print("1/4 separando o áudio...")
rodar([ffmpeg(), "-y", "-hide_banner", "-loglevel", "error", "-i", args.bruto, "-vn", "-ac", "1", "-ar", "16000", wav])
print("2/4 ouvindo o vídeo (na primeira vez baixa o dicionário de fala e demora mais)...")
try:
    from faster_whisper import WhisperModel
except ImportError:
    sys.exit("ERRO: falta a ferramenta que ouve o vídeo. Instale: python -m pip install faster-whisper")
modelo = WhisperModel(args.modelo, device="cpu", compute_type="int8", cpu_threads=os.cpu_count() or 4)
segs, _ = modelo.transcribe(wav, language="pt", word_timestamps=True, vad_filter=True, beam_size=1,
                            initial_prompt=args.vocabulario or None)
palavras = []
for s in segs:
    for w in s.words or []:
        if w.word.strip():
            palavras.append({"w": w.word.strip(), "t0": round(w.start, 2), "t1": round(w.end, 2)})
salvar_transcricao(tr0, palavras)
if not palavras:
    sys.exit("AVISO: não achei fala nesse vídeo. Ele tem som? Se for um vídeo sem fala, edite sem o corte de respiros.")
if args.so_texto:
    texto = " ".join(p["w"] for p in palavras)
    open(os.path.join(args.oficina, "texto.txt"), "w", encoding="utf-8").write(texto + "\n")
    try:
        os.remove(wav)
    except OSError:
        pass
    print("ok: só a transcrição (%d palavras) ->" % len(palavras), tr0)
    print("\n=== O QUE FOI FALADO ===")
    print(texto)
    sys.exit(0)

# 2. cortes pela fala
dur = duracao(args.bruto)
trechos = []
ini = max(0.0, palavras[0]["t0"] - folga)
for ant, prox in zip(palavras, palavras[1:]):
    if prox["t0"] - ant["t1"] > pausa_max:
        trechos.append([ini, ant["t1"] + folga])
        ini = max(ant["t1"] + folga, prox["t0"] - folga)
trechos.append([ini, min(dur, palavras[-1]["t1"] + max(folga, 0.25))])

# 3. uma passada: corta, deixa em pé, 30 quadros
print("3/4 gravando o vídeo sem os respiros, já em pé...")
expr = "+".join("between(t,%.3f,%.3f)" % (a, b) for a, b in trechos)
vf = ("select='%s',setpts=N/FRAME_RATE/TB,"
      "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30" % expr)
if args.hdr:
    vf = vf.replace("scale=1080", "zscale=t=linear:npl=100,tonemap=hable,zscale=t=bt709:m=bt709:r=tv,format=yuv420p,scale=1080", 1)
af = "aselect='%s',asetpts=N/SR/TB" % expr
saida_cmd = ["-vf", vf, "-af", af, "-c:v", "libx264", "-preset", "veryfast", "-crf", "17",
             "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", fim]
base = [ffmpeg(), "-y", "-hide_banner", "-loglevel", "error"]
r = subprocess.run(base + ["-hwaccel", "auto", "-i", args.bruto] + saida_cmd, capture_output=True,
                   text=True, encoding="utf-8", errors="replace")
if r.returncode != 0:  # sem aceleração de vídeo nesta máquina: vai do jeito normal
    rodar(base + ["-i", args.bruto] + saida_cmd)

palavras = remapear(palavras, trechos)
texto = salvar_transcricao(tr3, palavras)
try:
    os.remove(wav)
except OSError:
    pass

d3 = duracao(fim)
print("4/4 pronto.")
print("   duração: %.1f s -> %.1f s (%d pausa(s) cortada(s), começo e fim limpos)" % (dur, d3, len(trechos) - 1))
print("   vídeo sem respiros:", fim)
print("   transcrição:", tr3)
print("\n=== O QUE FOI FALADO (procure frase repetida ou começo errado) ===")
print(texto)
