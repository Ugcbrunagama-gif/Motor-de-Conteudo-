# -*- coding: utf-8 -*-
"""Funções comuns das ferramentas de edição (A Virada IA). Não é para rodar sozinho."""
import glob
import json
import os
import re
import shutil
import subprocess
import sys

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def ffmpeg():
    """Acha a ferramenta de vídeo, em qualquer lugar comum do Windows ou do Mac."""
    p = shutil.which("ffmpeg")
    if p:
        return p
    padroes = [
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Packages\Gyan.FFmpeg_*\ffmpeg-*\bin\ffmpeg.exe"),
        os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\WinGet\Links\ffmpeg.exe"),
        "/opt/homebrew/bin/ffmpeg",
        "/usr/local/bin/ffmpeg",
    ]
    for pad in padroes:
        achados = glob.glob(pad)
        if achados:
            return achados[0]
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        pass
    sys.exit("ERRO: não achei a ferramenta de vídeo (ffmpeg). Rode o check-up ou instale: "
             "winget install -e --id Gyan.FFmpeg  (Mac: brew install ffmpeg, ou pip install imageio-ffmpeg)")


def rodar(args, cwd=None):
    r = subprocess.run([str(a) for a in args], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", cwd=cwd)
    if r.returncode != 0:
        sys.exit("ERRO ao rodar: " + " ".join(str(a) for a in args[:6]) + " ...\n" + r.stderr[-2000:])
    return r


def duracao(video):
    r = subprocess.run([ffmpeg(), "-hide_banner", "-i", str(video)], capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    m = re.search(r"Duration: (\d+):(\d+):([\d.]+)", r.stderr)
    if not m:
        return 0.0
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def manter_trechos(video, trechos, saida, crf=17):
    """Monta um vídeo novo só com os trechos [ini, fim] da lista, emendados, áudio junto."""
    if not trechos:
        sys.exit("ERRO: nenhum trecho para manter.")
    expr = "+".join("between(t,%.3f,%.3f)" % (a, b) for a, b in trechos)
    vf = "select='%s',setpts=N/FRAME_RATE/TB" % expr
    af = "aselect='%s',asetpts=N/SR/TB" % expr
    rodar([ffmpeg(), "-y", "-hide_banner", "-loglevel", "error", "-i", video, "-vf", vf, "-af", af,
           "-c:v", "libx264", "-preset", "medium", "-crf", str(crf), "-pix_fmt", "yuv420p",
           "-c:a", "aac", "-b:a", "192k", saida])


def remapear(palavras, trechos):
    """Ajusta o tempo de cada palavra depois dos cortes. Palavras em trecho cortado saem."""
    novas, offset = [], 0.0
    limites = []
    for a, b in trechos:
        limites.append((a, b, offset))
        offset += b - a
    for p in palavras:
        meio = (p["t0"] + p["t1"]) / 2
        for a, b, off in limites:
            if a <= meio <= b:
                t0 = off + max(p["t0"], a) - a
                t1 = off + min(p["t1"], b) - a
                novas.append({"w": p["w"], "t0": round(t0, 2), "t1": round(max(t1, t0 + 0.05), 2)})
                break
    return novas


def ler_json(caminho):
    """Lê JSON em UTF-8 e, se vier com outra codificação (comum no Windows), tenta de novo."""
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return json.load(open(caminho, encoding=enc))
        except UnicodeDecodeError:
            continue
    return json.load(open(caminho, encoding="utf-8", errors="replace"))


def ler_transcricao(caminho):
    d = ler_json(caminho)
    if "palavras" in d:
        return d["palavras"]
    palavras = []
    for s in d.get("segmentos", []):
        palavras.extend(s.get("palavras", []))
    return palavras


def salvar_transcricao(caminho, palavras):
    texto = " ".join(p["w"].strip() for p in palavras)
    json.dump({"texto": texto, "palavras": palavras}, open(caminho, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    return texto


def hex_ass(cor, alfa=0):
    """#RRGGBB -> &HAABBGGRR (o formato de cor da legenda)."""
    c = cor.lstrip("#")
    r, g, b = c[0:2], c[2:4], c[4:6]
    return "&H%02X%s%s%s" % (alfa, b.upper(), g.upper(), r.upper())


def hex_rgb(cor):
    c = cor.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))
