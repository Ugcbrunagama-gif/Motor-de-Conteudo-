# -*- coding: utf-8 -*-
"""Monta a legenda na tela no padrão da pessoa (arquivo .ass, que o montar.py queima no vídeo).

uso: python legendas.py TRANSCRICAO.json PADRAO.json LEGENDAS.ass

PADRAO.json (tudo opcional; os valores abaixo são o padrão):
{
  "fonte": "Montserrat ExtraBold",   nome da família da fonte (veja bastidores.md, Fontes)
  "tamanho": 64,
  "cor": "#FFFFFF",
  "cor_destaque": "#F2B33D",          palavra-chave em outra cor
  "cor_contorno": "#000000",
  "contorno": 3, "sombra": 2,
  "maiusculas": false,
  "palavras_por_bloco": 3,            1 = palavra por palavra
  "margem_baixo": 520,                distância do pé da tela (520 deixa acima dos botões do Instagram)
  "destaques": [4, 17, 31]            posições das palavras-chave na transcrição (começa em 0)
}
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _comum import hex_ass, ler_json, ler_transcricao  # noqa: E402

if len(sys.argv) < 4:
    sys.exit(__doc__)
tr = ler_transcricao(sys.argv[1])
pd = ler_json(sys.argv[2]) if os.path.exists(sys.argv[2]) else {}
saida = sys.argv[3]

fonte = pd.get("fonte", "Montserrat ExtraBold")
tam = int(pd.get("tamanho", 64))
cor = hex_ass(pd.get("cor", "#FFFFFF"))
cor_dest = hex_ass(pd.get("cor_destaque", "#F2B33D"))
cor_cont = hex_ass(pd.get("cor_contorno", "#000000"))
sombra_cor = hex_ass("#000000", 0x80)
contorno = pd.get("contorno", 3)
sombra = pd.get("sombra", 2)
maius = bool(pd.get("maiusculas", False))
por_bloco = max(1, int(pd.get("palavras_por_bloco", 3)))
margem = int(pd.get("margem_baixo", 520))
destaques = set(pd.get("destaques", []))
cor_dest_tag = cor_dest.replace("&H00", "&H")


def ts(t):
    t = max(0.0, t)
    return "%d:%02d:%05.2f" % (int(t // 3600), int(t % 3600 // 60), t % 60)


def limpa(w):
    w = w.strip().replace("{", "").replace("}", "")
    if por_bloco > 1:
        w = w.rstrip(",;:")
    return w.upper() if maius else w


blocos, atual = [], []
for i, p in enumerate(tr):
    if atual:
        ant = tr[atual[-1]]
        pausa = p["t0"] - ant["t1"] > 0.45
        pontuacao = ant["w"].strip()[-1:] in ".!?"
        chars = len(" ".join(limpa(tr[j]["w"]) for j in atual)) + len(limpa(p["w"])) + 1
        if len(atual) >= por_bloco or pausa or pontuacao or chars > 22:
            blocos.append(atual)
            atual = []
    atual.append(i)
if atual:
    blocos.append(atual)


def palavra(i):
    w = limpa(tr[i]["w"])
    if i in destaques:
        return "{\\c%s&}%s{\\r}" % (cor_dest_tag, w)
    return w


cab = """[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Base,%s,%d,%s,%s,%s,%s,0,0,0,0,100,100,0,0,1,%s,%s,2,90,200,%d,1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
""" % (fonte, tam, cor, cor, cor_cont, sombra_cor, contorno, sombra, margem)

linhas = []
for k, b in enumerate(blocos):
    ini = tr[b[0]]["t0"]
    fim = tr[b[-1]]["t1"] + 0.15
    if k + 1 < len(blocos):
        fim = min(fim, tr[blocos[k + 1][0]]["t0"])
    linhas.append("Dialogue: 0,%s,%s,Base,,0,0,0,,%s" % (ts(ini), ts(fim), " ".join(palavra(i) for i in b)))

with open(saida, "w", encoding="utf-8") as f:
    f.write(cab + "\n".join(linhas) + "\n")
# o texto final (já corrigido) fica ao lado: serve para a legenda do post e para o motor
txt = os.path.join(os.path.dirname(os.path.abspath(saida)), "texto.txt")
with open(txt, "w", encoding="utf-8") as f:
    f.write(" ".join(p["w"].strip() for p in tr) + "\n")
print("ok: %d blocos de legenda -> %s (texto do vídeo em texto.txt)" % (len(blocos), saida))
