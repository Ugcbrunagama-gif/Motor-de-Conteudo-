# -*- coding: utf-8 -*-
"""Tira trechos do vídeo (erro de fala, frase repetida, começo errado) e ajusta a transcrição.

uso: python cortar.py VIDEO.mp4 TRANSCRICAO.json SAIDA.mp4 SAIDA-TRANSCRICAO.json "12.40-15.10" "20.0-21.3"

Cada trecho "ini-fim" (em segundos, do VIDEO de entrada) é removido. Para achar os tempos, leia a
transcrição: quando a pessoa errou e repetiu, corte do começo da tentativa ruim (t0 da primeira
palavra dela) até o começo da tentativa boa (t0 da primeira palavra que vale). Fica a ÚLTIMA versão.
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _comum import duracao, ler_transcricao, manter_trechos, remapear, salvar_transcricao  # noqa: E402

if len(sys.argv) < 6:
    sys.exit(__doc__)
video, trans, saida, saida_tr = sys.argv[1:5]
remover = []
for arg in sys.argv[5:]:
    a, b = arg.replace(",", ".").split("-")
    remover.append((float(a), float(b)))
remover.sort()

dur = duracao(video)
manter, pos = [], 0.0
for a, b in remover:
    if a > pos:
        manter.append([pos, a])
    pos = max(pos, b)
if pos < dur:
    manter.append([pos, dur])

manter_trechos(video, manter, saida)
palavras = remapear(ler_transcricao(trans), manter)
texto = salvar_transcricao(saida_tr, palavras)
print("ok: %d trecho(s) removido(s). %.1f s -> %.1f s" % (len(remover), dur, duracao(saida)))
print(texto)
