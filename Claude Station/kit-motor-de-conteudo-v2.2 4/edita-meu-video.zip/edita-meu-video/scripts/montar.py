# -*- coding: utf-8 -*-
"""Junta tudo no Reel final: vídeo sem respiros + zoom + preto e branco + cor + peças + legenda + sons.

uso: python montar.py PLANO.json          (rode com o PLANO dentro da pasta da oficina)
     python montar.py PLANO.json --teste 20   (só os primeiros 20 segundos, para aprovar antes)

PLANO.json (caminhos relativos à pasta do plano; só "video" e "saida" são obrigatórios):
{
  "video": "03-cortado.mp4",
  "saida": "REEL.mp4",
  "legendas": "legendas.ass", "fontes_dir": "fontes",
  "pecas":  [ {"png": "pecas/titulo.png", "ini": 0, "fim": 2.8} ],
  "zooms":  [ {"ini": 12.4, "fim": 17.0, "z": 1.12} ],     fecha na frase forte e segura; sem vaivém
  "pb":     [ [20.0, 24.5] ],                               trechos em preto e branco
  "cor":    {"quente": 0.3, "contraste": 1.05, "saturacao": 1.05, "brilho": 0.0},
  "sons":   [ {"wav": "sons/whoosh.wav", "t": 0.0, "vol": 0.5} ],
  "musica": {"arquivo": "musica.mp3", "volume": 0.10},
  "qualidade": "rapida"                                     "alta" grava mais devagar, com arquivo melhor
}
Tempo: a gravação leva mais ou menos de 1 a 3 vezes a duração do vídeo, conforme o computador.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _comum import duracao, ffmpeg, ler_json, rodar  # noqa: E402

if len(sys.argv) < 2:
    sys.exit(__doc__)
plano_path = os.path.abspath(sys.argv[1])
pasta = os.path.dirname(plano_path)
pl = ler_json(plano_path)
teste = None
if "--teste" in sys.argv:
    teste = float(sys.argv[sys.argv.index("--teste") + 1])

entradas = ["-i", pl["video"]]
n_in = 1
filtros = []
v = "0:v"

# zoom suave (entra e sai em 0,35 s), parado no meio
zooms = pl.get("zooms", [])
if zooms:
    termos = []
    for z in zooms:
        a, b, k = float(z["ini"]), float(z["fim"]), float(z.get("z", 1.12)) - 1
        termos.append("between(it,%.2f,%.2f)*%.3f*min(1,(it-%.2f)/0.35)*min(1,(%.2f-it)/0.35)" % (a, b, k, a, b))
    zexpr = "1+" + "+".join(termos)
    filtros.append("[%s]scale=1620:2880,zoompan=z='%s':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=1080x1920:fps=30[vz]" % (v, zexpr))
    v = "vz"

# cor
cor = pl.get("cor")
if cor:
    q = float(cor.get("quente", 0))
    filtros.append("[%s]eq=contrast=%.3f:saturation=%.3f:brightness=%.3f,colorbalance=rs=%.3f:bs=%.3f:rm=%.3f:bm=%.3f[vc]" % (
        v, cor.get("contraste", 1.0), cor.get("saturacao", 1.0), cor.get("brilho", 0.0),
        0.06 * q, -0.06 * q, 0.04 * q, -0.04 * q))
    v = "vc"

# preto e branco em trechos
pb = pl.get("pb", [])
if pb:
    en = "+".join("between(t,%.2f,%.2f)" % (a, b) for a, b in pb)
    filtros.append("[%s]hue=s=0:enable='%s'[vpb]" % (v, en))
    v = "vpb"

# peças por cima
for i, p in enumerate(pl.get("pecas", [])):
    entradas += ["-i", p["png"]]
    filtros.append("[%s][%d:v]overlay=0:0:enable='between(t,%.2f,%.2f)'[vo%d]" % (v, n_in, p["ini"], p["fim"], i))
    v = "vo%d" % i
    n_in += 1

# legenda por cima de tudo
if pl.get("legendas"):
    fd = pl.get("fontes_dir")
    sub = "subtitles=%s" % pl["legendas"] + (":fontsdir=%s" % fd if fd else "")
    filtros.append("[%s]%s[vl]" % (v, sub))
    v = "vl"

# áudio: voz + sons + música
a = "0:a"
mix = []
for j, s in enumerate(pl.get("sons", [])):
    entradas += ["-i", s["wav"]]
    ms = int(float(s["t"]) * 1000)
    filtros.append("[%d:a]adelay=%d|%d,volume=%.2f[s%d]" % (n_in, ms, ms, float(s.get("vol", 0.5)), j))
    mix.append("[s%d]" % j)
    n_in += 1
if pl.get("musica"):
    entradas += ["-stream_loop", "-1", "-i", pl["musica"]["arquivo"]]
    filtros.append("[%d:a]volume=%.2f[mus]" % (n_in, float(pl["musica"].get("volume", 0.10))))
    mix.append("[mus]")
    n_in += 1
if mix:
    filtros.append("[0:a]%samix=inputs=%d:duration=first:dropout_transition=0:normalize=0[aout]" % ("".join(mix), len(mix) + 1))
    a = "aout"

cmd = [ffmpeg(), "-y", "-hide_banner", "-loglevel", "error"] + entradas
if filtros:
    cmd += ["-filter_complex", ";".join(filtros)]
cmd += ["-map", "[%s]" % v if filtros and not v.endswith(":v") else v,
        "-map", "[%s]" % a if a == "aout" else a]
saida = pl["saida"]
if teste:
    cmd += ["-t", str(teste)]
    raiz, ext = os.path.splitext(saida)
    saida = raiz + "-teste" + ext
alta = pl.get("qualidade") == "alta"
cmd += ["-c:v", "libx264", "-preset", "medium" if alta else "veryfast", "-crf", "18" if alta else "19", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", saida]

print("montando..." + (" (teste de %ds)" % teste if teste else ""))
rodar(cmd, cwd=pasta)
print("ok:", os.path.join(pasta, saida), "(%.1f s)" % duracao(os.path.join(pasta, saida)))
