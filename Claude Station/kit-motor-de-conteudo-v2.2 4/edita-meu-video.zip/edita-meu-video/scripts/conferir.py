# -*- coding: utf-8 -*-
"""Confere o vídeo antes de mostrar, e ajuda a escolher a capa.

uso:
  python conferir.py grade  VIDEO.mp4 [REFERENCIA.mp4]   grade de 12 quadros (grade.jpg) e a duração
  python conferir.py teste  VIDEO.mp4                     4 quadros dos primeiros 20 s (teste-4-quadros.jpg)
  python conferir.py contato VIDEO.mp4                    1 quadro por segundo, para escolher a capa (contato.jpg)
  python conferir.py quadro VIDEO.mp4 7.5 SAIDA.jpg        tira um quadro no segundo 7,5

Na grade, confira: legenda batendo com a fala, texto longe do rodapé e da coluna da direita
(área segura: x 60 a 900, y 250 a 1470), zoom sem vaivém, nada cortado.
"""
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _comum import duracao, ffmpeg, rodar  # noqa: E402

if len(sys.argv) < 3:
    sys.exit(__doc__)
modo, video = sys.argv[1], sys.argv[2]
pasta = os.path.dirname(os.path.abspath(video))
d = duracao(video)

if modo == "grade":
    out = os.path.join(pasta, "grade.jpg")
    rodar([ffmpeg(), "-y", "-hide_banner", "-loglevel", "error", "-i", video,
           "-vf", "fps=%.4f,scale=270:-1,tile=6x2" % (12.0 / max(d, 1)), "-frames:v", "1", out])
    print("duração: %.1f s" % d)
    if len(sys.argv) > 3:
        r = duracao(sys.argv[3])
        print("referência: %.1f s (diferença %.2f s; até 0,3 s está ok)" % (r, abs(r - d)))
    print("grade:", out)
elif modo == "teste":
    out = os.path.join(pasta, "teste-4-quadros.jpg")
    fim = min(20.0, d)
    rodar([ffmpeg(), "-y", "-hide_banner", "-loglevel", "error", "-t", "%.2f" % fim, "-i", video,
           "-vf", "fps=%.4f,scale=360:-1,tile=4x1" % (4.0 / max(fim, 1)), "-frames:v", "1", out])
    print("4 quadros:", out)
elif modo == "contato":
    out = os.path.join(pasta, "contato.jpg")
    linhas = max(1, math.ceil(min(d, 48) / 8))
    rodar([ffmpeg(), "-y", "-hide_banner", "-loglevel", "error", "-i", video,
           "-vf", "fps=%.4f,scale=200:-1,tile=8x%d" % (min(1.0, 48.0 / max(d, 1)), linhas), "-frames:v", "1", out])
    print("contato:", out, "(um quadro por segundo, da esquerda para a direita)")
elif modo == "quadro":
    t, out = float(sys.argv[3]), sys.argv[4]
    rodar([ffmpeg(), "-y", "-hide_banner", "-loglevel", "error", "-ss", "%.2f" % t, "-i", video,
           "-frames:v", "1", "-q:v", "2", out])
    print("quadro:", out)
else:
    sys.exit(__doc__)
