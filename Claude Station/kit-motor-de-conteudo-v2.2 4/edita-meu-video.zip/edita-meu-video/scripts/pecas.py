# -*- coding: utf-8 -*-
"""Gera as peças visuais do vídeo, nas cores e fontes da pessoa: título, cartela, número, logo e capa.

uso: python pecas.py PECAS.json

PECAS.json:
{
  "saida_dir": "pecas",
  "fontes": { "titulo": "fontes/Anton-Regular.ttf", "texto": "fontes/Montserrat-Bold.ttf",
              "destaque": "fontes/OutraFonte.ttf" },          destaque é opcional
  "cores":  { "fundo": "#14373C", "texto": "#FFFFFF", "destaque": "#C4835E" },
  "pecas": [
    {"tipo": "titulo", "arquivo": "titulo.png", "selo": "PARTE 3",
     "linhas": [[{"s": "3 coisas que"}], [{"s": "ninguém", "d": true}, {"s": "te conta"}]], "y": 470},
    {"tipo": "numero", "arquivo": "num1.png", "rotulos": ["ANTES", "DEPOIS"], "valores": ["2 h", "10 min"], "y": 330},
    {"tipo": "cartela", "arquivo": "resumo.png", "linhas": [[{"s": "Resumindo"}], [{"s": "faça", "d": true}, {"s": "hoje"}]]},
    {"tipo": "logo", "arquivo": "logo.png", "logo": "marca/logo.png", "altura": 66, "opacidade": 0.7},
    {"tipo": "capa", "arquivo": "capa.jpg", "foto": "quadro.jpg", "selo": "PARTE 3",
     "linhas": [[{"s": "3 coisas que"}], [{"s": "ninguém", "d": true}]], "titulo_y": 1250}
  ]
}
Cada linha é uma lista de partes. Parte com "d": true sai na cor de destaque (e na fonte de destaque, se
houver). Títulos saem em caixa alta. Tudo que precisa ser lido fica entre y 250 e 1470 (área segura).
"""
import json
import os
import sys
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _comum import hex_rgb, ler_json  # noqa: E402

try:  # fotos do iPhone (.HEIC)
    from pillow_heif import register_heif_opener
    register_heif_opener()
except ImportError:
    pass

if len(sys.argv) < 2:
    sys.exit(__doc__)
W, H = 1080, 1920
cfg = ler_json(sys.argv[1])
FONTES = cfg["fontes"]
CORES = cfg.get("cores", {})
FUNDO = hex_rgb(CORES.get("fundo", "#14373C"))
TEXTO = hex_rgb(CORES.get("texto", "#FFFFFF"))
DEST = hex_rgb(CORES.get("destaque", "#C4835E"))
SAIDA = Path(cfg.get("saida_dir", "pecas"))
SAIDA.mkdir(parents=True, exist_ok=True)


def fonte(tipo, tam):
    caminho = FONTES.get(tipo) or FONTES.get("titulo")
    return ImageFont.truetype(caminho, int(tam))


def medir(d, partes, tam):
    itens = []
    for p in partes:
        if p.get("d"):
            f = fonte("destaque" if FONTES.get("destaque") else "titulo", tam)
            txt = p["s"] if FONTES.get("destaque") else p["s"].upper()
            itens.append((txt, f, DEST, d.textlength(txt, font=f)))
        else:
            f = fonte("titulo", tam)
            itens.append((p["s"].upper(), f, None, d.textlength(p["s"].upper(), font=f)))
    esp = d.textlength(" ", font=fonte("titulo", tam))
    return itens, esp, sum(i[3] for i in itens) + esp * (len(itens) - 1)


def escrever(img, linhas, y, tam, cor, alinhar="centro", x0=90, largura_max=900):
    d = ImageDraw.Draw(img)
    for partes in linhas:
        t = tam
        itens, esp, total = medir(d, partes, t)
        while total > largura_max and t > 40:
            t -= 4
            itens, esp, total = medir(d, partes, t)
        x = W / 2 - total / 2 if alinhar == "centro" else x0
        for txt, f, c, w in itens:
            d.text((x, y), txt, font=f, fill=(c or cor) + (255,), anchor="ls")
            x += w + esp
        y += int(t * 1.12)
    return y


def com_sombra(camada, raio=8, opac=0.55):
    alfa = camada.split()[3].filter(ImageFilter.GaussianBlur(raio)).point(lambda v: int(v * opac))
    sombra = Image.new("RGBA", camada.size, (0, 0, 0, 0))
    sombra.putalpha(alfa)
    sombra.alpha_composite(camada)
    return sombra


def logo_redim(caminho, altura, opacidade=1.0):
    m = Image.open(caminho).convert("RGBA")
    m = m.resize((max(1, round(m.width * altura / m.height)), altura), Image.LANCZOS)
    if opacidade < 1:
        m.putalpha(m.split()[3].point(lambda v: int(v * opacidade)))
    return m


def titulo(p):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    y, tam = p.get("y", 470), p.get("tam", 96)
    if p.get("selo"):
        ImageDraw.Draw(img).text((W / 2, y - tam - 18), p["selo"].upper(), font=fonte("texto", 38),
                                 fill=DEST + (255,), anchor="ms")
    escrever(img, p["linhas"], y, tam, TEXTO)
    com_sombra(img).save(SAIDA / p["arquivo"])


def cartela(p):
    img = Image.new("RGBA", (W, H), FUNDO + (p.get("opacidade", 235),))
    tam = p.get("tam", 100)
    alt = len(p["linhas"]) * int(tam * 1.12)
    escrever(img, p["linhas"], p.get("y", int(860 - alt / 2 + tam * 0.8)), tam, TEXTO)
    if p.get("rodape"):
        ImageDraw.Draw(img).text((W / 2, 1400), p["rodape"], font=fonte("texto", 28),
                                 fill=TEXTO + (220,), anchor="ms")
    img.save(SAIDA / p["arquivo"])


def numero(p):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    y = p.get("y", 330)
    d.rounded_rectangle((90, y, 990, y + 330), radius=28, fill=FUNDO + (230,))
    for cx, rot, val in zip((315, 765), p["rotulos"], p["valores"]):
        d.text((cx, y + 85), rot.upper(), font=fonte("texto", 36), fill=TEXTO + (255,), anchor="ms")
        tam = p.get("tam", 120)
        while d.textlength(val, font=fonte("titulo", tam)) > 380 and tam > 50:
            tam -= 4
        d.text((cx, y + 235), val, font=fonte("titulo", tam), fill=DEST + (255,), anchor="ms")
    d.line((540, y + 50, 540, y + 270), fill=DEST + (160,), width=2)
    if p.get("nota"):
        d.text((540, y + 310), p["nota"], font=fonte("texto", 26), fill=TEXTO + (200,), anchor="ms")
    img.save(SAIDA / p["arquivo"])


def logo(p):
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    img.alpha_composite(logo_redim(p["logo"], p.get("altura", 66), p.get("opacidade", 0.7)),
                        (p.get("x", 80), p.get("y", 270)))
    img.save(SAIDA / p["arquivo"])


def capa(p):
    foto = ImageOps.exif_transpose(Image.open(p["foto"])).convert("RGB")
    foto = ImageOps.fit(foto, (W, H), Image.LANCZOS, centering=(0.5, p.get("foco_y", 0.4)))
    img = foto.convert("RGBA")
    veu = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    dv = ImageDraw.Draw(veu)
    de = p.get("veu_de", 950)
    for yy in range(de, H):
        dv.line((0, yy, W, yy), fill=FUNDO + (int(235 * min(1.0, (yy - de) / max(1.0, (H - de) * 0.55))),))
    img.alpha_composite(veu)
    tam, ty = p.get("tam", 96), p.get("titulo_y", 1250)
    if p.get("selo"):
        ImageDraw.Draw(img).text((90, ty - tam - 30), p["selo"].upper(), font=fonte("texto", 36),
                                 fill=DEST + (255,), anchor="ls")
    escrever(img, p["linhas"], ty, tam, TEXTO, alinhar="esq", x0=90)
    if p.get("logo"):
        img.alpha_composite(logo_redim(p["logo"], 70), (90, 320))
    img.convert("RGB").save(SAIDA / p["arquivo"], quality=92)


TIPOS = {"titulo": titulo, "cartela": cartela, "numero": numero, "logo": logo, "capa": capa}
for peca in cfg["pecas"]:
    TIPOS[peca["tipo"]](peca)
    print("ok", SAIDA / peca["arquivo"])
