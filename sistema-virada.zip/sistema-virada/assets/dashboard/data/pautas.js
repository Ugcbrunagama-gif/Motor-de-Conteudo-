/* Radar de pautas. continuidade = o que já bombou NOS DADOS DA PESSOA (desdobramentos);
 * radarExterno = o que os criadores que ela acompanha e as fontes do nicho dela publicaram.
 * Cada pauta: { id, titulo, angulo, origem:{ tipo:"continuidade"|"radar", fonte, referencia,
 * performance (só continuidade, ex "+160% vs media"; "" no radar) }, porqueAgora,
 * inputPronto (o texto pronto pra colar no Claude: "Roda o motor ...") }
 * O botão "Rodar o motor" do painel copia o inputPronto. Proibido travessão nos textos. */
window.VIRADA_PAUTAS = {
  continuidade: [],
  radarExterno: []
};
