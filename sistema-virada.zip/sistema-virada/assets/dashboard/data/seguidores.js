/* Evolução rumo à meta. meta = o alvo da pessoa (seguidores ou outro número acompanhável).
 * serie: um ponto por dia { data:"AAAA-MM-DD", seguidores: total, ganho: saldo do dia }.
 * Com Metricool: IGEV01 (total) e IGEV03 (saldo). Precisa de 2+ pontos pra seção aparecer.
 * NUNCA encurte a série: só acrescente/atualize dias. */
window.VIRADA_SEGUIDORES = {
  meta: 10000,
  serie: []
};
