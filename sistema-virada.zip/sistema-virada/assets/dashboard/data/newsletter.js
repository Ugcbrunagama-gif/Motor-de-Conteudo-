/* Newsletter semanal. Atualizado quando a pessoa compila/envia a newsletter (Módulo 7).
 * lista: { total, ativos, novosSemana, descadastrosSemana } (null = sem dado ainda).
 * edicoes: [{ data, assunto, status:"rascunho"|"enviada", enviados, aberturas, cliques,
 * openRate, ctr, linkTop }] */
window.VIRADA_NEWSLETTER = {
  proximoEnvio: "",
  statusProximo: "rascunho_pendente",
  lista: { total: null, ativos: null, novosSemana: null, descadastrosSemana: null },
  edicoes: []
};
