/* Metadados do painel. A Construtora/radar reescreve a cada atualização. */
window.VIRADA_META = {
  atualizadoEm: "2026-01-01T07:30:00-03:00", // ISO 8601 com fuso
  geradoPor: "setup inicial",                // quem rodou (ex.: "radar diário")
  brandId: 0,                                // brandId do Metricool da pessoa (0 = ainda sem conector)
  periodoDias: 30
};
