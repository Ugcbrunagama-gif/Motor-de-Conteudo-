/* Posts publicados no período. O index.html calcula KPIs, média, destaque e gráfico sozinho.
 * Um objeto por post: data, titulo (curto, no tom da pessoa), url, views, salvos,
 * comentarios, compartilhamentos. */
window.VIRADA_RESULTADOS = [];
