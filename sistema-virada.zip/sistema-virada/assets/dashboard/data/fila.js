/* Posts agendados. { quandoData:"Ter 7", quandoHora:"07h30", redes:["ig","tk","yt","li"],
 * formato:"Reel", titulo:"...", subtitulo:"(opcional)", status:"ok"|"wait"|"draft" } */
window.VIRADA_FILA = [];
