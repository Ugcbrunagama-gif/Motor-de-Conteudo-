# Central de Conteúdo do aluno (contrato de dados)

Este painel é a versão do aluno da Central da Bruna, com 100% das funcionalidades:
KPIs, gráfico de views, tabela de resultados (vs. média), destaque do período, card
"Rumo à meta" (com comemoração), fila de agendados, RADAR DE PAUTAS (continuidade +
radar externo, com botão "Rodar o motor" que copia o inputPronto) e newsletter.

REGRA DE OURO: NUNCA edite o index.html. Os dados moram em data/*.js
(meta, seguidores, resultados, fila, pautas, newsletter). O index.html lê e desenha.

Quem escreve nos data/*.js: a Construtora (na criação/atualização) e o radar diário
(radar-diario.md). O radar NÃO toca em newsletter.js (isso é do fluxo da newsletter).
Depois de reescrever, valide com node --check (se o node existir) e confira que não
há travessão (traço longo) em nenhum texto.

Personalização (a Construtora faz na criação, com a seção "## Marca" do perfil.md):
{{NOME}}, {{NEGOCIO}}, {{ARROBA}} no index.html; as cores da marca no :root (--terra* = cor
principal, --green* = apoio); a fonte dos títulos em --display e no link do Google Fonts;
e {{LOGO}}: troque por <img class="marcaLogo" src="logo.png" alt=""> com o logo copiado para
esta pasta, ou por nada, se a pessoa não tem logo.

O céu é o limite: o painel é da pessoa. Se ELA pedir mudança (seção nova, outro
layout, tirar/acrescentar bloco), pode mudar o index.html à vontade; nesse caso,
atualize este README e o radar-diario.md junto, pra rotina continuar batendo com a
estrutura. O que não muda: agentes automáticos (radar) nunca alteram o visual por
conta própria, só os data/*.js.
