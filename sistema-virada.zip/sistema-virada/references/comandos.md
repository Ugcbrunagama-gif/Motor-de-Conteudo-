# Comandos do dia a dia

Estes comandos funcionam a qualquer momento, mesmo depois dos módulos concluídos. Leia este arquivo
quando a pessoa pedir um deles. As Regras de Ouro do SKILL.md valem o tempo todo (em especial: nada de
rede social sem o "sim" dela). **Antes de qualquer chamada ao Metricool, leia `references/metricool.md`
(formato de data, brandId, códigos de métrica): sem ele as chamadas falham.**

## "me dá pautas" / "roda meu radar"

O radar de pautas, igual ao da Bruna.

**Se o `meu-sistema/radar-diario.md` já existe** (Módulo 8 feito): leia e EXECUTE aquele arquivo, ele é
o manual da rotina personalizada da pessoa. É o mesmo radar que roda agendado.

**Se ainda não existe** (versão sob demanda):
1. Leia `perfil.md` (pilares, inspirações/concorrentes, fontes do nicho, meta) e `base-conteudo.md`
   (pra NUNCA repetir pauta já feita).
2. **Pesquise de verdade**: busque na web o que os criadores/concorrentes dela postaram de mais quente
   recentemente e o que saiu de novidade nas fontes do nicho dela. Se o Metricool estiver ligado, puxe
   também os números dos últimos posts DELA (o que performou melhor), seguindo `references/metricool.md`.
3. Entregue **5 pautas** com: título, ângulo em 1 frase (por que agora), a fonte da ideia (qual criador
   ou site inspirou) e a palavra-chave sugerida. Priorize pautas que cruzam: assunto quente no nicho ×
   pilar dela × o que já performou pra ela.
4. Termine oferecendo: "quer que eu rode o motor com alguma dessas?" e, se o Módulo 8 ainda não foi
   feito, "quer que eu deixe esse radar rodando sozinho todo dia? É o Módulo 8, leva 5 minutos".

## "analisa minha semana" / "como foi meu conteúdo"

Com o Metricool ligado, puxe os resultados dos posts recentes dela, compare com a META de 90 dias do
`perfil.md` (está no caminho? quanto falta?), atualize a Central (`dashboard/data/`: resultados.js,
seguidores.js e meta.js, no formato do `dashboard/README.md`) e feche com 1 recomendação prática
("esse formato está performando, dobra a aposta" / "esse horário rendeu mais"). Sem o Metricool, peça os
prints dela e faça a mesma leitura.

## "monta meu dashboard"

Se a Central ainda não existe, rode o Módulo 6 agora (leia `references/modulos-6-8.md`: copie o molde
`assets/dashboard/` inteiro, personalize os tokens e semeie os `data/*.js`). Se já existe, trate como
"atualiza meu dashboard".

## "atualiza meu dashboard" / "atualiza minha meta"

Se o `radar-diario.md` existe, execute ele (é o fluxo completo de atualização). Se não, puxe os dados
(Metricool se ligado, senão base-conteudo + o que ela contar) e reescreva os `dashboard/data/*.js` por
ela (resultados, fila, seguidores/meta, meta.js), sempre no formato do `dashboard/README.md`, sem
nunca editar o index.html.

## "refazer meu perfil"

Reabra o Módulo 1 (leia `references/modulos-0-2.md`): antes de perguntar, releia a pasta
`meu-sistema/materiais/` (a pessoa pode ter jogado material novo lá: o dossiê do perfil, dados do
Metricool, posts, e-mails). Depois, mande todas as perguntas de uma vez, numeradas, mostrando a resposta antiga de cada uma pra confirmar ou trocar.
Reescreva `perfil.md` e ofereça regenerar o motor com o perfil novo.

## "analisa meu perfil"

Rode a Parte A do Módulo 1 avulsa (leia `references/modulos-0-2.md`), começando SEMPRE pela leitura da
pasta `meu-sistema/materiais/`.

## "guarda isso nos meus materiais" (ou a pessoa manda um arquivo/análise avulsa)

Se a pessoa mandar uma análise nova (o dossiê, Metricool, prints), um texto dela, ou qualquer material do
negócio fora de hora: salve dentro de `meu-sistema/materiais/` com um nome claro (ex.:
`analise-metricool-2026-07.md`) e diga que ficou guardado pra próxima análise de perfil.

## "faz um check-up" / "confere meu sistema" / "travei" / "deu erro"

Leia `references/checkup.md` e rode. No "travei", rode só os itens ligados ao que ela estava fazendo,
resolva o que der e, se não resolver, entregue o pedido pronto para o suporte (modelo no próprio arquivo).

## "abre meu painel" / "onde você salvou?" / "abre para mim"

Diga o caminho em português de gente ("está na pasta meu-sistema, dentro de dashboard") e abra para ela:
o painel no Chrome (Windows: `start chrome "<caminho>"`; Mac: `open -a "Google Chrome" "<caminho>"`) e
pastas no gerenciador de arquivos (Windows: `explorer "<pasta>"`; Mac: `open "<pasta>"`). Se ela ainda não
salvou o painel nos favoritos, sugira: Ctrl + D (no Mac, Command + D).

