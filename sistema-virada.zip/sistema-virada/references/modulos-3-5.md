# Módulos 3 a 5 · Edição, Formatos e Distribuição

Leia este arquivo quando a pessoa estiver em qualquer um destes módulos. As Regras de Ouro do SKILL.md
valem o tempo todo. **No Módulo 5 (e em qualquer chamada ao Metricool), leia ANTES o
`references/metricool.md`: é ele que tem o formato de data, o brandId e os códigos que fazem as
chamadas funcionarem. Sem ele, as chamadas falham e a pessoa fica sem o agendamento.**

## MÓDULO 3 · EDIÇÃO DE VÍDEO (com a assinatura da pessoa)

Objetivo: a pessoa sair com a edição DELA ensinada ao Claude, não com a da Bruna. O caminho é o mesmo
que a Bruna usou para criar a dela: referência, processo contado, teste num vídeo cru, ajuste, e só
então a skill é gravada. **A skill vem por último, nunca primeiro.**

0. **Antes de tudo, as ferramentas.** Se o item "Ferramentas de vídeo e transcrição" do check-up não
   está ok no `progresso.md`, rode a seção 2 do `references/checkup.md` agora, com aviso antes.
1. Explique em 2 frases: "criar o conteúdo é metade. A outra é o vídeo ficar bom, e você não precisa de
   programa complicado: você conta como edita, me mostra referências, e eu aprendo o seu jeito."
2. **Confira a skill de edição de partida.** O LEIA-ME do kit manda instalar as duas skills no começo; veja
   se a `edita-meu-video` já está instalada. Se não estiver: PROCURE a pasta
   do kit nos lugares comuns (Downloads, Desktop, Documentos). Achou: copie `edita-meu-video` para a
   pasta de skills, do mesmo jeito do motor, e valide que `...\skills\edita-meu-video\SKILL.md` existe.
   Se não achar o kit, peça para a pessoa instalar o `edita-meu-video.zip` (na Central do aluno) pelo app (Personalizar >
   Habilidades > Adicionar > Fazer upload), ou siga sem ela: você mesmo edita por aqui.
2b. **Leia o `SKILL.md` e o `references/bastidores.md` da `edita-meu-video`.** Daqui em diante, siga
   a seção "Primeira vez" dela: as ferramentas prontas estão em `scripts/` da skill. Em TODO vídeo,
   sem a pessoa pedir, a fala é transcrita palavra por palavra, todos os respiros saem
   automaticamente e frase repetida ou começo errado é cortado (fica a última versão).
3. **Crie a gaveta de referências:** `meu-sistema/videos-de-referencia/`. Peça, numa mensagem só,
   numerada (é o pedido da seção "Primeira vez" da `edita-meu-video`): (1) de 1 a 5 vídeos DELA que
   ficaram do jeito que ela gosta; (2) de 1 a 3 vídeos de criadores que ela admira, com o que ela gosta
   em cada um (o arquivo ou o link, que você baixa); (3) como edita hoje, do jeito que sair, pode ser por
   áudio: app (CapCut, Edits, InShot...), legenda, título, fonte, cortes, zoom, filtro, música; (4) o
   ritmo: calmo, com respiro no fim da frase, ou rápido, com corte seco; (5) o que ela nunca quer ver
   no vídeo; (6) a marca, SÓ se a seção `## Marca` do `perfil.md` ainda não existe (Regra de Ouro 13).
   Se ela não tem padrão nenhum, diga que este é o momento de criar um, e ofereça partir do vídeo dela
   que mais performou (o dossiê ou o Metricool ajudam a achar).
4. **Analise as referências quadro a quadro** (nos bastidores, sem tecniquês) e devolva o padrão em
   linguagem de gente: posição e estilo do título, tipo de legenda (palavra a palavra, frase inteira),
   cor, ritmo dos cortes, zoom, filtro. **Confronte com o que ela contou** e pergunte tudo de uma vez o
   que não bateu ("você disse legenda animada, mas na referência é frase inteira: qual vale?").
5. **Teste de 20 segundos antes do vídeo inteiro:** peça UM vídeo cru (`meu-sistema/videos-crus/`; se a
   esteira do Módulo 5 já existe, a pasta 1 - VÍDEOS CRUS). Se a edição demorar demais ou faltar espaço,
   veja a seção 6 do `references/checkup.md` (o celular). Monte uma ficha curta com o padrão para ela aprovar de uma vez.
   Edite SÓ os primeiros 20 segundos e mostre 4 quadros. Ajustar ali é barato em tempo e no limite do
   plano. Aprovou? Edite o resto. Confira você mesmo antes de mostrar: monte uma folha de quadros e procure
   legenda com erro, texto atrás dos botões do Instagram, corte seco, zoom indo e voltando. Avise que
   demora uns minutos e que a primeira versão quase nunca é a final. Diga onde salvou e ofereça abrir.
6. **Ajuste com ela como se fosse um funcionário:** "os zooms podem ser mais fortes", "o título entra
   depois". Repita até ela dizer que está bom. Se ela tentar pular para gravar a skill antes de ver o
   resultado, segure: primeiro o resultado bom, depois a skill.
6b. **A capa:** mostre 3 ou 4 quadros com olhar na câmera para ela escolher e monte a capa no padrão
   dela. Avise: no Instagram, a capa não troca depois de publicado.
7. **Grave a assinatura:** preencha a seção `## A assinatura` do `SKILL.md` da `edita-meu-video`
   instalada com o modelo que está lá (ritmo, dicionário de palavras, legenda, título, peças, zoom,
   cor, sons, capa, o que nunca fazer, pasta de referências), salve o padrão da legenda e das peças em
   `meu-sistema/minha-edicao/` e guarde a mesma assinatura em `meu-sistema/minha-edicao.md` (backup). No Cowork, entregue também o `.skill` atualizado para ela
   instalar pelo app, se a pasta de skills não estiver ao seu alcance.
8. Ensine o recado central: **"o céu é o limite."** Filtro no rosto, logo de uma marca, print atrás de
   você, ilustração: é só pedir, e se ficar bom, mandar gravar na skill. A skill melhora com o uso.
   Conte também o atalho de quem já está rodando: gravar vários vídeos de uma vez, jogar todos na
   pasta de crus e pedir "edita todos esses no meu padrão".
9. Marque o Módulo 3, comemore.

## MÓDULO 4 · EXPANDIR FORMATOS E O CARROSSEL COM ARTE

Objetivo: mostrar que um input vira vários formatos e, se a pessoa usa carrossel, montar com ela a
skill que entrega a ARTE pronta (PNG), no estilo dela. Leia `references/carrossel.md` antes da parte B.

### Parte A · Um input, vários formatos
1. Rode o motor num tema e mostre saírem os formatos das redes DELA (carrossel em texto, LinkedIn,
   Threads, etc.). Se algum formato sair fraco (o LinkedIn costuma sair), ofereça o mesmo método do
   vídeo: "me manda 3 posts seus que você gosta e eu ajusto o motor no seu tom".

### Parte B · A arte do carrossel (só se ela usa carrossel; pergunte)
Se ela não usa carrossel, marque como pulado e siga. Se usa, confira antes o item "Imagens do
carrossel" do check-up (seção 3 do `references/checkup.md`). Depois:
2. **Referências e marca primeiro, numa mensagem só, numerada:** (1) de 3 a 5 carrosséis que ela ama
   (prints ou links; dela ou de quem admira), em `meu-sistema/referencias-carrossel/`; (2) a marca, SÓ
   se a seção `## Marca` do `perfil.md` ainda não existe (Regra de Ouro 13; se existe, confirme e use):
   manual, logo, cartão, site ou o próprio feed (a marca vem ANTES das fotos), e salve na seção depois
   do ok; (3) que fotos ela tem:
   profissionais, de celular, nenhuma, ou prints de tela; (4) se tem conselho profissional (saúde,
   direito, nutrição): muda o que pode ir no slide.
3. **Escolha o estilo:** compare as referências com os seis estilos de partida em `assets/carrossel/`
   (claro, escuro, colorido, editorial, etiqueta e print, mosaico; o cardápio está em
   `references/carrossel.md`). Proponha o mais próximo, dizendo por quê em uma linha. Se nenhum chega
   perto das referências, parta do mais parecido e transforme até ficar com a cara das referências: o
   molde é andaime, não fôrma.
4. **Monte o primeiro carrossel de verdade:** pegue o texto slide a slide da última rodada do motor (ou
   rode uma), preencha a ficha da marca dela no molde, renderize os PNG 1080x1350 e confira um por um.
   Mostre e ajuste até ela aprovar. Diga onde salvou as imagens e ofereça abrir a pasta.
5. **Só depois do "aprovo", grave a skill dela:** crie `meu-carrossel` (pasta de skills; no Cowork,
   entregue também o `.skill`) com: o `SKILL.md` (quando acionar, o fluxo texto aprovado > arte > PNG,
   as regras de texto e de conselho, o passo de render), o molde já com a marca dela em
   `assets/molde.html` e o passo a passo de render. Atualize o `meu-motor` para oferecer a arte logo
   depois de entregar o texto do carrossel ("quer que eu já monte a arte?").
6. **Seja honesto sobre o limite:** a arte sai do molde dela, sempre no mesmo padrão (o que é bom para
   o reconhecimento). Estilo novo é pedido novo: manda referência, ajusta, grava.
7. Marque o Módulo 4, comemore: "Um input, vários formatos. E agora o carrossel sai com a arte pronta."

## MÓDULO 5 · DISTRIBUIÇÃO E AGENDAMENTO (Metricool)

Objetivo: conectar a distribuição e **agendar de verdade** um post de teste. Aqui a pessoa põe a mão na
conexão, guie clique a clique, em blocos curtos de até 3 passos.

Explique: "o Metricool é grátis e agenda seus posts em várias redes de uma vez. A gente conecta ele ao
Claude pra você agendar só conversando comigo, sem abrir dez telas."

Se a pessoa não quiser criar a conta agora, respeite: "tranquilo, deixa a distribuição manual por
enquanto: eu preparo as legendas prontas e você cola na rede. Quando quiser automatizar, é só me falar
'quero conectar o Metricool'". Marque o módulo como pulado no progresso e siga pro Módulo 6.

### Parte A · Conectar (a pessoa faz, você guia)
1. Criar conta grátis em `metricool.com`.
2. Conectar SÓ as redes que a pessoa usa (do `perfil.md`). Avise: "pro Instagram funcionar, a conta
   precisa ser profissional (business/creator). Se a sua é pessoal, dá pra trocar de graça nas
   configurações do Instagram, e eu te explico como." TikTok, YouTube e Threads também se ligam lá; às
   vezes o Metricool pede para entrar pelo Facebook, e isso é normal.
3. Conectar o Metricool ao Claude. Caminho principal: no app do Claude, **Configurações > Conectores >
   Procurar conectores**, buscar **Metricool**, conectar e fazer login na conta dela. Se não aparecer
   no diretório, plano B (é o que a aula mostra): **Personalizar > Conectores > Adicionar conector
   personalizado**, nome "Metricool", endereço `https://ai.metricool.com/mcp`, Adicionar e fazer login
   na página que abrir. Nas permissões, sugira "sempre permitir" para não ficar perguntando a cada uso.

Quando conectar, **TESTE na hora que funcionou de verdade** (não dê o módulo por feito sem isso):
descubra o `brandId` da conta DELA via `getBrandSettings` (guarde no `perfil.md`; nunca use o de outra
pessoa) e faça UMA chamada real de leitura, ex.: `getBestTimeToPostByNetwork`, mostrando pra pessoa o
resultado ("olha, o teu melhor horário no Instagram é X"). Siga o `references/metricool.md` à risca
(formato de data ISO completo com fuso!). Bônus: com o conector ligado, ofereça salvar um relatório dos
melhores posts dela dentro de `meu-sistema/materiais/` (vira matéria-prima pra análises futuras).

### Parte A2 · A esteira no Google Drive (recomendada)

O Metricool não lê o computador dela: o vídeo precisa morar num link. A esteira resolve isso de vez e
deixa o dia a dia em "gravei, subi, pedi".

1. Explique em 2 frases: "vamos montar a sua esteira: você grava no celular e sobe numa pasta do Drive. Eu
   edito, salvo o pronto em outra pasta e agendo de lá, sem você copiar link nenhum."
2. **A pessoa instala** o Google Drive para computador (google.com/drive/download) e entra com a conta
   Google dela. Confira se a unidade apareceu (seção 4 do `references/checkup.md`).
3. **A pessoa conecta** o Google Drive no Claude: Configurações › Conectores › Google Drive › Conectar.
4. **Você cria** no Drive dela a pasta `MEU CONTEÚDO` com `1 - VÍDEOS CRUS`, `2 - REELS PRONTOS` e
   `3 - CAPAS`.
5. **A pessoa compartilha** a pasta `MEU CONTEÚDO` como "qualquer pessoa com o link pode ver" (botão
   direito › Compartilhar › Acesso geral). Diga: "só quem tem o link vê, e o link não fica exposto em lugar
   nenhum. Mesmo assim, nessa pasta só vai o que é para postar."
6. **Você anota** os três caminhos no `perfil.md`, numa seção `## Esteira`. A partir daqui a edição salva
   os prontos na pasta 2 e as capas na 3.
7. **Teste o link:** com um vídeo qualquer na pasta 1, ache o arquivo pelo conector do Drive, monte o link
   de download direto (ver Parte B, passo 1) e confira que ele abre como vídeo.
8. Ensine o dia a dia no celular: app do Google Drive › + › Fazer upload › pasta 1 - VÍDEOS CRUS. "Gravou
   cinco? Sobe os cinco de uma vez."

Se ela não quiser o Drive, siga com o link manual (Dropbox com `?dl=1` no fim, ou outro link público).

### Parte B · O comando do dia a dia: "distribui esse vídeo"

Sempre que a pessoa disser **"distribui esse vídeo: [link]"** (ou variação), rode este fluxo. É o jeito
oficial de publicar pelo sistema.

1. **O vídeo precisa estar num link que a internet acessa.** O Metricool não lê o computador dela.
   - **Com a esteira:** copie o vídeo pronto para `2 - REELS PRONTOS` (se ainda não estiver lá), espere o
     Drive subir (busque o arquivo pelo conector do Drive até ele aparecer), pegue o `id` e monte o link
     de download direto:
     `https://drive.usercontent.google.com/download?id=ID-DO-ARQUIVO&export=download&confirm=t`.
     **Nunca use o link de visualização** (`drive.google.com/file/d/.../view`): ele devolve a página do
     Drive, e o agendamento falha com erro de mídia.
   - **Teste o link antes de agendar:** baixe o começo dele nos bastidores e confirme que vem um vídeo, e
     não uma página. Se vier página, o link está no formato errado ou a pasta não está compartilhada.
   - **Sem esteira:** peça o link público (Drive compartilhado, convertido para o link direto acima, ou
     Dropbox com `?dl=1`). Nada de caminho `C:\...`.
   - **Erro de mídia no agendamento:** suspeite PRIMEIRO do formato do link, depois da permissão da
     pasta, e só por último do arquivo.
   - **A capa vai junto:** se houver capa na pasta `3 - CAPAS`, monte o mesmo link direto para ela e mande
     no agendamento (ver `references/metricool.md`). Depois de publicado, o Instagram não deixa trocar.
2. **Formato do vídeo, resolvido nos bastidores.** Vídeo de iPhone costuma vir num formato que o Metricool
   não aceita. Isso é problema SEU, não dela: se der pra ajeitar aqui, você ajeita calado; se não der,
   diga em português de gente "seu vídeo precisa de um ajustezinho de formato, me manda que eu cuido" ou
   oriente ela a exportar como vídeo comum. **NUNCA fale nome de programa técnico com ela.**
3. **Tema e legenda.** Pergunte o tema em 1 frase (ou reaproveite da `base-conteudo.md`) e monte a legenda
   adaptada pra CADA rede dela, seguindo as regras do motor (gancho na linha 1, CTA com palavra-chave,
   hashtags conforme a rede; YouTube com título e #Shorts; Threads curto, de conversa, sem lista de
   hashtags).
4. **Melhor horário.** Se ela não disser quando, pegue o melhor horário de cada rede com
   `getBestTimeToPostByNetwork` (o `brandId` dela, timezone `America/Sao_Paulo`). Sem o conector ligado,
   sugira horários típicos do nicho dela (ex.: almoço e início da noite) e pergunte qual prefere.
5. **PREVIEW no chat:** mostre, rede por rede, exatamente o que vai subir (legenda + horário), diga que
   **nada foi agendado ainda** e pergunte: "posso agendar assim?".
6. **Só depois do "sim" explícito**, agende de verdade com `createScheduledPost` (uma chamada por rede,
   com o `brandId`/`blogId` dela, a data com fuso, a legenda e o link do vídeo). Se o conector não estiver
   ligado ainda, entregue as legendas prontas pra ela colar no Metricool na mão e guie onde colar.
7. **Confirme** o que ficou agendado, rede por rede, com dia e hora. **Se o dashboard já existir**
   (Módulo 6 feito), atualize o `dashboard/data/fila.js`: acrescente esses posts na fila. Se ainda não existir,
   guarde mentalmente: eles entram na semeadura do Módulo 6. Nada de rede social sem o "sim" dela.

Marque o Módulo 5, comemore: "Seu conteúdo agora tem por onde sair, agendado sozinho."
