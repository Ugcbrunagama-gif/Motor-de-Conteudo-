# O check-up (computador, contas e rotina)

Leia este arquivo:
- no **Módulo 0**, logo depois de criar a pasta `meu-sistema` (é o check-up de entrada);
- quando a pessoa disser **"faz um check-up"**, "confere meu sistema", "travei", "não está funcionando",
  "deu erro" ou variação;
- antes do **Módulo 3** (edição), do **Módulo 4, Parte B** (arte do carrossel) e do **Módulo 5**
  (distribuição), se o item correspondente não estiver marcado como ok no `progresso.md`.

O objetivo é simples: descobrir AGORA o que falta, e não no meio da edição de um vídeo. Você confere
quase tudo sozinho. A pessoa só põe a mão no que só ela pode fazer (autorizar, digitar a senha do
computador, criar conta, mexer no celular).

## Regras do check-up

1. **Português de gente.** A pessoa nunca vê nome de ferramenta de bastidor. Fale de função: "a
   ferramenta que ouve os vídeos", "a que corta e junta o vídeo", "a que gera as imagens do carrossel".
   Os aplicativos que ELA abre (Chrome, Google Drive, Metricool, CapCut) podem ser citados pelo nome.
2. **Avise antes de instalar, sempre.** Antes de qualquer instalação, diga numa frase o que vai
   instalar, para que serve e o que pode aparecer: "vou instalar a ferramenta que ouve os seus vídeos.
   Pode abrir uma janela pedindo permissão ou a senha do seu computador: é normal, pode aceitar." Só
   instale depois do "pode". Nunca instale nada calado.
3. **Faça você mesmo tudo que der.** Conferir, instalar, testar e criar pastas é com você. Se algo
   falhar, tente o caminho seguinte antes de pedir ajuda à pessoa.
4. **Teste de verdade.** Ferramenta "instalada" que não roda não conta. Rode um teste curto de cada
   uma antes de marcar ok.
5. **Registre.** Atualize a seção `## Check-up` do `progresso.md` com a data e um ok ou pendente em
   cada item (formato no fim deste arquivo).
6. **Uma mensagem de resultado, curta.** Mostre a lista com ok e pendente e, para cada pendente, quem
   resolve (eu ou você) e o próximo passo. Nada de despejar log técnico.

## O que conferir

### 1. A casa
- A pasta de trabalho aberta nesta conversa (anote o caminho completo) e se a `meu-sistema` está lá.
- **Espaço livre no disco.** Vídeo ocupa espaço (um minuto gravado em 4K passa de 300 MB). Abaixo de
  10 GB livres, avise e sugira liberar espaço ou gravar em 1080p (seção 6).

### 2. As ferramentas de vídeo e de transcrição (para o dossiê e a edição)
Confira, nos bastidores:
- o Python 3 (Windows: `py --version` ou `python --version`; Mac: `python3 --version`);
- a ferramenta que corta e junta vídeo (`ffmpeg -version`);
- a ferramenta que ouve os vídeos e escreve o que foi falado (um pacote de transcrição no Python, como
  o `faster-whisper`);
- a ferramenta que baixa vídeo pelo link (`yt-dlp`);
- as que desenham título, capa e legenda e leem foto de iPhone (`pillow`, `pillow-heif`, `numpy`).

Caminhos que costumam funcionar, do mais simples ao mais garantido. Use o que der certo na máquina dela:
- **Windows:** `winget install --id Python.Python.3.12 -e --scope user` para o Python e
  `winget install --id Gyan.FFmpeg -e` para a de vídeo. Depois, os pacotes do Python numa pasta só do
  sistema: `py -m venv "<meu-sistema>\.ferramentas"` e, com ele, `pip install faster-whisper yt-dlp
  imageio-ffmpeg pillow pillow-heif numpy`.
- **Mac:** se houver Homebrew, `brew install python ffmpeg`. Se não houver, use o Python que existir e
  instale os pacotes num ambiente próprio (`python3 -m venv "<meu-sistema>/.ferramentas"`), os mesmos do
  Windows, incluindo o `imageio-ffmpeg`, que traz a ferramenta de vídeo sem precisar de senha de
  administrador.
- Anote no `progresso.md` qual Python e qual caminho funcionaram, para as próximas conversas não
  repetirem a busca.

**Teste:** gere um vídeo de 2 segundos (cor sólida com som) com a ferramenta de vídeo, converta para
mp4 e confirme que o arquivo abriu; confirme que os pacotes carregam
(`import faster_whisper, PIL, numpy`). As ferramentas de edição da `edita-meu-video` (pasta
`scripts/` dela) rodam com esse mesmo Python. Avise que a primeira
transcrição de verdade baixa um "dicionário" grande e demora mais: é só da primeira vez.

### 3. As imagens do carrossel
O carrossel vira imagem pelo navegador Chrome (ou Edge), em modo invisível. Confira se o Chrome existe
(Windows: `C:\Program Files\Google\Chrome\Application\chrome.exe` ou a pasta do usuário; Mac:
`/Applications/Google Chrome.app`). **Teste:** gere uma imagem de 1080x1350 a partir de uma página simples
com texto e confira que o arquivo saiu com o texto certo. Sem Chrome nem Edge, peça para instalar o Chrome
(google.com/chrome) e explique: "é por ele que eu desenho as imagens do seu carrossel".

### 4. As contas e os conectores
- **Metricool:** se o conector estiver disponível, leia `references/metricool.md` e chame
  `getBrandSettings`. Respondeu? Anote o `brandId` no `perfil.md` e liste quais redes estão ligadas lá
  e quais das redes dela (do `perfil.md`) ainda faltam. Lembre: Instagram precisa ser conta
  profissional, e às vezes o Metricool pede para entrar pelo Facebook. Se o conector não existir, é
  pendente da pessoa, com o caminho: Configurações › Conectores › procurar "Metricool" › Conectar.
- **Google Drive (para o Módulo 5):** confira se o conector do Google Drive responde (uma busca simples)
  e se o Google Drive para computador está instalado (Windows: uma unidade com "Meu Drive" ou "My Drive";
  Mac: `~/Library/CloudStorage/GoogleDrive-*`). Só informe; a esteira é montada no Módulo 5.

### 5. As skills e o modelo
- A `edita-meu-video` aparece na sua lista de skills? Se não, peça para subir o arquivo pelo app
  (Personalizar › Habilidades › Fazer upload).
- Lembre em uma frase: para montar o sistema, o modelo mais forte do plano; para o dia a dia, o mais leve.

### 6. O celular (só quando resolver um problema)
O 4K não aparece no Reel (o post sai em 1080p), mas tem uma vantagem: o zoom na frase forte continua
nítido. Por isso, NÃO sugira mudar a câmera só porque o vídeo veio em 4K. Sugira apenas quando o peso
do vídeo estiver atrapalhando de verdade:
- a edição está demorando demais (a pessoa reclamou, ou um vídeo curto levou muito tempo);
- o espaço no computador está abaixo de 10 GB, ou o Google Drive dela está quase cheio.
Nesses casos, explique o ganho e a troca em uma frase ("gravando em 1080p o vídeo fica bem menor e eu
edito mais rápido; o zoom fica um pouco menos nítido") e mostre onde mudar:
- **iPhone:** Ajustes › Câmera › Gravar Vídeo › 1080p a 30 qps.
- **Android:** na câmera, engrenagem › resolução do vídeo › 1080p (FHD).
Fale disso uma vez só. Se ela preferir manter o 4K, siga e converta nos bastidores. Formato que o
agendador recusa é problema seu: converta calado, sem pedir para ela mudar nada.

### 7. O radar (só depois do Módulo 8)
Leia a última linha de `meu-sistema/radar-log.md`. Se o radar não rodou nos últimos 2 dias, explique as
causas mais comuns, em ordem: o computador estava desligado ou o aplicativo do Claude estava fechado no
horário; a tarefa ficou parada esperando uma permissão (oriente a escolher "permitir sempre" para a pasta
do sistema); a tarefa foi apagada (crie de novo, Módulo 8, passo 3). Ofereça rodar agora: "roda meu radar".

## Quando a pessoa disse "travei"

Rode os itens que têm a ver com o que ela estava fazendo (não precisa rodar tudo). Resolva o que der. Se
não resolver, monte o pedido de ajuda pronto para ela mandar ao suporte (suporte@brunasantanna.com), sem
senha, sem dado de cliente:

```
Suporte do Motor de Conteúdo
Computador: [Windows ou Mac]
Onde parei: [módulo e passo, do progresso.md]
O que eu estava fazendo: [uma frase]
O que aconteceu: [a mensagem de erro, em uma linha]
Check-up: [a lista com ok e pendente]
```

## Formato no progresso.md

```
## Check-up (última vez: AAAA-MM-DD)
- [ok] Pasta e espaço em disco (XX GB livres)
- [ok] Ferramentas de vídeo e transcrição (Python em: ...)
- [ok] Imagens do carrossel (Chrome em: ...)
- [pendente] Metricool: falta ligar o TikTok (a pessoa)
- [ok] Google Drive no computador e conector
- [ok] Skill de edição instalada
- [--] Radar (Módulo 8 ainda não feito)
```

Comemore em uma frase quando estiver tudo ok: "Computador pronto. Daqui para a frente é conteúdo."
