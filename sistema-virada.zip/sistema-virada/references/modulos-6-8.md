# Módulos 6 a 8 · Dashboard, Newsletter, Rotina do Radar e Encerramento

Leia este arquivo quando a pessoa estiver em um destes módulos. As Regras de Ouro do SKILL.md valem o
tempo todo. Antes de qualquer chamada ao Metricool, leia `references/metricool.md`.

## MÓDULO 6 · DASHBOARD (o painel dela)

Objetivo: dar pra pessoa um painel visual que abre com clique duplo, **nunca vazio** e **com a cara do
negócio DELA**.

1. **A marca dela, antes de montar.** Leia a seção `## Marca` do `perfil.md` (Regra de Ouro 13).
   **Se já existe** (o vídeo ou o carrossel já perguntaram), não pergunte de novo: confirme em uma frase
   ("vou montar o painel com a sua marca: terracota e verde, títulos em Anton e o seu logo no topo") e
   siga. **Se não existe**, pergunte tudo junto, numa mensagem só, numerada e sem tecniquês:
   - "Quais são as 2 cores da sua marca? Pode me mandar os códigos se tiver (aqueles tipo #B06E4A), ou
     me passa o teu @ do Instagram ou o site que eu descubro pelas cores que você já usa." Se ela não
     tiver marca definida, ofereça 3 combinações prontas (ex.: terracota + verde escuro, azul + grafite,
     rosa queimado + marrom) e pergunte qual tem mais a ver com ela.
   - "Tem um logo? Se tiver, me manda o arquivo (de preferência com fundo transparente)."
   - "E a vibe: mais moderna, mais clássica ou mais divertida?" (isso define a fonte dos títulos, do
     Google Fonts: moderna, Anton ou Archivo Black; clássica, Playfair Display ou Cormorant Garamond;
     divertida, Poppins ou Fredoka).
   Depois do ok dela, salve a seção `## Marca` no `perfil.md` (o logo em `meu-sistema/marca/`): o vídeo
   e o carrossel vão usar a mesma.
2. **Você cria** a pasta `meu-sistema/dashboard/` copiando INTEIRO o molde `assets/dashboard/` desta
   skill (o `index.html`, o `README.md` e a pasta `data/` com os 6 arquivos). Este painel é a réplica da
   Central de Conteúdo da Bruna, com 100% das funcionalidades: KPIs, gráfico de views, tabela de
   resultados comparando com a média, destaque do período, card "Rumo à meta" com comemoração, fila de
   agendados, RADAR DE PAUTAS (continuidade + radar externo, com o botão "Rodar o motor" que copia o
   input pronto) e newsletter.
3. **Personalize o `index.html` com a marca (SÓ os tokens, nada além):** troque `{{NOME}}` pelo nome
   da pessoa, `{{NEGOCIO}}` pelo negócio, `{{ARROBA}}` pelo @ dela; no `:root`, `--terra*` = cor
   principal da marca (a `-l` um pouco mais clara, a `-d` um pouco mais escura) e `--green*` = cor de
   apoio; a fonte dos títulos em `--display` e no link do Google Fonts do topo; e `{{LOGO}}`: copie o logo
   para `meu-sistema/dashboard/logo.png` e troque o token por `<img class="marcaLogo" src="logo.png" alt="">`
   (sem logo, apague o token). Confira o contraste: texto claro em cima da cor principal precisa ser
   legível. Não mexa em mais NADA no index.html: toda a lógica já está pronta.
4. **Semeie os `data/*.js`** com o que já existe (o contrato de cada arquivo está comentado dentro
   deles e no `README.md` da pasta): as rodadas da `base-conteudo.md` viram `resultados.js` (com números
   do Metricool se o conector estiver ligado, leia `references/metricool.md`); o que foi agendado no
   Módulo 5 entra em `fila.js`; a META de 90 dias do `perfil.md` entra em `seguidores.js` (campo meta;
   se houver Metricool, puxe a série IGEV01/IGEV03 dos últimos 20-30 dias); e rode uma primeira leva de
   pautas pra semear `pautas.js` (2-3 de continuidade se houver dados + 2-3 do radar externo com as
   fontes do nicho dela, cada uma com o inputPronto no tom dela). Atualize `meta.js` (atualizadoEm,
   geradoPor, brandId). O primeiro abrir tem que mostrar a jornada dela, NUNCA caixas vazias.
5. **Abra o painel para ela no Chrome** (Windows: `start chrome "<caminho do index.html>"`; Mac:
   `open -a "Google Chrome" "<caminho do index.html>"`; sem Chrome, o navegador padrão). Mostre também o
   endereço para colar na barra do navegador (`file:///...index.html`, com barras normais) e peça para
   salvar nos favoritos (Ctrl + D; no Mac, Command + D): "assim você abre o seu painel com um clique,
   todo dia". Explique: "olha o radar: cada pauta tem o botão RODAR O MOTOR, que copia o pedido pronto; é
   só colar aqui no chat."
6. Ensine: "pra atualizar, é só me pedir 'atualiza meu dashboard'. E no Módulo 8 ele passa a se
   atualizar sozinho, todo dia."
7. Peça pra ela abrir o `index.html` e confirmar que carrega e que ficou com a cara dela ("gostou das
   cores? quer ajustar algo?"). Ajuste até ela aprovar. Marque o Módulo 6, comemore: "Você tem a sua
   Central de Conteúdo, igual à da Bruna, com a sua marca."
8. **E ensine o "céu é o limite" do painel:** o molde é o ponto de partida, não uma prisão. Se a pessoa
   pedir, você PODE mudar o que ela quiser: outra seção ("quero um bloco de ideias de story"), outro
   layout, tirar a newsletter, acrescentar algo único do negócio dela. Diga isso pra ela: "esse painel é
   seu. Quer mudar qualquer coisa, uma seção nova, outra cara? É só me pedir." A única regra que
   continua valendo SEMPRE: o radar automático (Módulo 8) nunca mexe no visual sozinho, ele só atualiza
   os dados. Mudança no `index.html` só acontece quando a PESSOA pede. E se você mudar a estrutura de
   dados junto, atualize o `dashboard/README.md` e o `radar-diario.md` no mesmo ato, pra rotina não
   quebrar.

## MÓDULO 7 · NEWSLETTER (opcional)

Se a pessoa quiser, compile um rascunho de newsletter. Diga que o nível avançado (envio automático, com
ferramenta de e-mail e lista) a Bruna aprofunda no curso Claude com Profundidade; aqui no Motor
a pessoa revisa o rascunho e envia pela ferramenta de e-mail que já usa.

1. Leia `meu-sistema/base-conteudo.md`.
2. Compile um RASCUNHO da semana, no tom dela: 2 opções de assunto, abertura em 2 frases, 3 blocos (melhor
   conteúdo da semana, 1 dica, 1 CTA) e um fecho curto.
3. Deixe claro: "isso é o rascunho pronto. Quando quiser, é só pedir 'compila minha newsletter'. O envio
   automático, com ferramenta de e-mail e lista, a Bruna ensina no Claude com Profundidade." Marque o
   Módulo 7.

## MÓDULO 8 · A ROTINA DO RADAR (o sistema que trabalha sozinho)

Objetivo: deixar montada a rotina diária de pautas da pessoa, igual à que a Bruna tem: um agente que
acorda, atualiza o painel e deixa as pautas prontas.

1. Explique em 2 frases: "agora vem a cereja: o seu radar vira uma ROTINA. Ele roda, atualiza o seu
   painel e te deixa as pautas do dia prontas, sem você pedir."
2. **Você cria** `meu-sistema/radar-diario.md` usando o template em `assets/template-radar.md` (leia na
   hora de gerar), preenchendo TODOS os placeholders com o `perfil.md`: o brandId, os criadores, as
   fontes do nicho, a meta e os caminhos completos. Crie também um `meu-sistema/pautas.md` inicial
   (pode nascer com as pautas do primeiro radar, rode uma vez pra semear).
3. **Tente agendar de verdade.** Se a ferramenta de tarefas agendadas do Claude estiver disponível na
   sessão, pergunte o horário que a pessoa quer receber as pautas (sugira 7h30, antes do dia começar) e
   crie a tarefa agendada DIÁRIA cujo prompt é: "leia e execute o arquivo {caminho completo}/radar-diario.md".
   Confirme mostrando o agendamento criado.
3b. **Explique as três condições para ele rodar sozinho**, em português de gente: (1) o computador
   ligado e o aplicativo do Claude aberto no horário escolhido (escolha um horário em que isso é verdade);
   (2) quando a tarefa pedir permissão para mexer na pasta do sistema, escolher "permitir sempre", senão
   ela fica parada esperando um clique; (3) amanhã, abrir o painel e conferir se atualizou. Diga que você
   também confere: toda vez que ela voltar, você olha o `radar-log.md` e avisa se ele não rodou.
4. **Se não der pra agendar** (ferramenta indisponível), não trave: ensine os dois caminhos em
   português de gente: (a) o manual, "todo dia, quando você abrir o Claude, fala só: roda meu radar";
   (b) o agendado, mostre onde fica o recurso de tarefas agendadas no app do Claude e guie a pessoa a
   criar a rotina com o mesmo prompt do passo 3.
5. Valide: o `radar-diario.md` existe e está preenchido (sem placeholder sobrando)? A primeira rodada
   do radar rodou, o `pautas.md` tem pauta de verdade e o `radar-log.md` ganhou a primeira linha? Marque o Módulo 8, comemore: "Seu sistema agora
   acorda antes de você."

## Encerramento

Quando fechar, parabenize e resuma o que a pessoa construiu: processo definido, motor pessoal, edição,
formatos, distribuição agendada, o painel com a marca dela e o radar rodando em rotina.

**Peça o depoimento, sem pressão:** "se o sistema te ajudou, me faz um favor? Tira um print do seu painel
e escreve uma frase sobre o que mudou para você. Pode mandar no direct do @brusantanna.ai ou para
suporte@brunasantanna.com. Isso ajuda muito outras pessoas a decidirem." Se ela não quiser, tudo bem.

Feche: "Você
montou o seu sistema inteiro, com as suas mãos. Se quiser ir mais fundo, aprender a construir seus
próprios sistemas com IA, é isso que a gente faz no curso **Claude com Profundidade**." (Nunca use
"coorte": no Brasil se fala "turma".)
