# Carrossel com arte · manual do Módulo 4, Parte B

Leia antes de montar a arte do carrossel. Tudo aqui é bastidor seu: a pessoa vê só o resultado, em
português de gente. Nada de "headless", "render" ou "token" na conversa com ela.

Os seis estilos de partida ficam em `assets/carrossel/`. **Nunca edite os arquivos de lá.** Copie
para `meu-sistema/carrossel/` e trabalhe na cópia. Todos são 1080x1350 e mostram um slide por vez
com `?s=N` no endereço.

## 1. O cardápio dos seis estilos

Escolha primeiro pelo que a pessoa TEM (fotos), depois pela cara do negócio.

| Ela tem | Servem | Não servem |
|---|---|---|
| Foto profissional boa | 1, 2 | |
| Só foto de celular, desigual | 4 (o preto e branco uniformiza) ou 5 | 1, 2 |
| Muitas fotos medianas | 6 (soma quatro por slide) | |
| Nenhuma foto | 3 | 4, 6 |
| Tela para mostrar (ferramenta, resultado, prova) | 5 | |

| Estilo | Cara | Para quem |
|---|---|---|
| 1 · Editorial claro | bege, número gigante, anotação à mão | quem ensina passo a passo e quer parecer próximo |
| 2 · Escuro premium | fundo escuro, fio fino, índice lateral | quem vende caro: saúde, direito, consultoria. O mais versátil |
| 3 · Colorido cheio | cor chapada, tipografia gigante | público jovem, quem não quer aparecer. Funciona sem foto |
| 4 · Editorial afetivo | foto preto e branco com grão, serifa | comportamento, reflexão, marca pessoal. Exige foto de pessoa |
| 5 · Etiqueta e print | fundo claro, etiqueta de cor, print de tela | mostrar ferramenta, antes e depois, prova. Ganha `fotos/prints/` |
| 6 · Mosaico | quatro fotos em grade, faixas de texto desalinhadas | lista, resumo da semana, catálogo. Faixas tortas de propósito |

Os estilos trazem como amostra a capa, um slide do meio e o fecho (o 6 vem só com capa e meio). Para
montar oito slides, crie os que faltam copiando a estrutura e as classes do próprio estilo.

**Referência que não bate com nenhum:** parta do mais próximo e transforme (cores, fontes, posição do
título, proporção de foto) até ficar com a cara das referências dela. Mostre a capa para ela aprovar
antes de fazer os outros slides.

## 2. A ficha da marca

O bloco `:root` no topo de cada estilo é o único que muda de uma marca para outra. Abaixo do
comentário "daqui para baixo e igual para todo mundo", não mexa (exceção: entrelinha da serifa, abaixo).

**De onde tirar a marca, nesta ordem:** a seção `## Marca` do `perfil.md` (se o vídeo ou o painel já
perguntaram, está lá: use e não pergunte de novo); manual de marca; logo, cartão, site, assinatura de e-mail; o
feed dela; as fotos, só em último caso. A marca vem antes da foto: cor tirada da foto, quando a pessoa
já tem identidade, é a primeira coisa que ela nota como errada. Sem nada disso, ofereça três
combinações e peça para escolher.

| Token | O que é |
|---|---|
| `--acao`, `--acao-cl`, `--acao-esc` | cor de destaque (número, botão, etiqueta) e as variações clara e escura |
| `--fundo`, `--fundo-alt` | fundo do slide e a variação |
| `--claro`, `--tinta` | cor do texto |
| `--display`, `--corpo` | as duas fontes, do Google Fonts |
| `--peso-display` | 400 para fonte pesada sem serifa, 600 para serifa |
| `--glow`, `--moldura` | brilho atrás do título e fio de borda, quando houver |
| `--pb`, `--escuro` | só no estilo 4: preto e branco e brilho da foto |
| `--etiqueta`, `--realce` | só no estilo 5 |

- **Trocou a fonte no token, troque no `<link>` do Google Fonts.** Fonte não carregada vira Times New
  Roman e só aparece no PNG.
- A fonte exata da marca quase nunca está no Google. Escolha a mais próxima e diga em uma linha
  ("a do seu logo é uma serifa clássica; a mais parecida disponível é a Cinzel"). Atalhos: serifa
  clássica, Cinzel ou Cormorant Garamond; serifa de revista, Playfair Display; sem serifa pesada,
  Archivo Black ou Anton; geométrica, Poppins ou Outfit; condensada de cartaz, Bebas Neue.
- **Serifa em caixa alta pede** `h1{ line-height:1.16; letter-spacing:.012em; }`, senão o til encosta
  na linha de cima.
- **Dados sensíveis:** cartão e print costumam trazer telefone, CPF, PIX. Nada disso entra no slide.
  Tire a cor e a fonte e não guarde a imagem original.

**Fotos:** reduza para uns 1700px de altura antes de usar (foto pesada some do slide sem aviso);
guarde os originais em `fotos/originais/`; nomeie por função (`f-capa`, `f-retrato`, `f-corpo`,
`f-cta`). `object-position` é o enquadramento: o segundo valor menor mostra mais do topo.

## 3. O texto vem antes da arte

Entregue o texto slide a slide, espere o "aprovo", e só então monte. Montar arte antes de acertar o
texto é retrabalho garantido. Se o motor dela já tem regras de carrossel, valem as dela. Se não:

| # | Função |
|---|---|
| 1 | Gancho: decide o primeiro arrastar. Título curto |
| 2 | A dor, com contexto: a pessoa se reconhece na primeira linha |
| 3 | A virada: o que muda de entendimento, em uma frase |
| 4 a 6 | Os passos: verbo de ação e o ganho de cada um |
| 7 | A prova: número, fonte, credencial, sem inventar |
| 8 | O convite: um pedido só |

Nunca: "não é X, é Y" (tique de texto de IA); biografia, número ou caso inventado; travessão;
jargão sem explicação. **Conselho profissional** (psicologia, medicina, odontologia, direito,
nutrição): sem promessa de resultado, sem caso de paciente ou cliente, sem depoimento, sem antes e
depois; o convite vira "me chama para conversar". Entregue junto a legenda e o texto alternativo de
cada slide.

## 4. Gerar os PNG

Um PNG por slide, 1080x1350, pelo navegador Chrome (ou Edge) em modo invisível. Antes, confira se o
navegador existe na máquina dela. Se não houver, peça para instalar o Chrome (explique: "é por ele
que eu transformo o slide em imagem").

**Windows (PowerShell):**
```powershell
$chrome = "C:\Program Files\Google\Chrome\Application\chrome.exe"   # ou o msedge.exe
$dir  = "<pasta do carrossel>\slides"
$base = "file:///C:/.../carrossel-<tema>.html"   # espaço vira %20
foreach ($i in 1..8) {
  $out  = Join-Path $dir ("slide-$i.png")
  $prof = Join-Path $env:TEMP ("cr-" + [guid]::NewGuid().ToString("N"))
  & $chrome --headless=new --disable-gpu --hide-scrollbars --no-sandbox `
    --user-data-dir="$prof" --force-device-scale-factor=1 --virtual-time-budget=15000 `
    --window-size=1080,1350 --screenshot="$out" ($base + "?s=" + $i) 2>$null | Out-Null
  Start-Sleep -Milliseconds 1800
}
```

**Mac (Terminal):**
```bash
CHROME="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
for i in 1 2 3 4 5 6 7 8; do
  "$CHROME" --headless=new --disable-gpu --hide-scrollbars \
    --user-data-dir="$(mktemp -d)" --force-device-scale-factor=1 --virtual-time-budget=15000 \
    --window-size=1080,1350 --screenshot="slides/slide-$i.png" "file://$PWD/carrossel-TEMA.html?s=$i"
  sleep 2
done
```

As armadilhas, todas já conhecidas:
1. **Perfil novo a cada slide** (`--user-data-dir` único). Com o Chrome dela aberto, sem isso todos
   os PNG saem iguais, sem erro.
2. **`--virtual-time-budget=15000` sempre**, senão a fonte não carrega a tempo.
3. **Caminho com espaço** vira `%20` no endereço `file://`.
4. **O arquivo aparece depois que o navegador fecha.** Confira a data de modificação, não só o nome.

**Confira o lote antes de mostrar:** tamanhos quase iguais em todos = perfil colidiu, refaça; um
arquivo muito menor = slide sem foto; uns 20 KB = página em branco (caminho ou `?s=` errado). Depois
olhe cada PNG: acento encostando, título estourando, texto sumindo na foto. **Nunca conserte o PNG:
corrija o HTML e gere de novo.**

Se gerar PNG não for possível na máquina dela de jeito nenhum, entregue o HTML aberto no navegador e
ensine a tirar print de cada slide, sem travar o módulo.

## 5. A skill que nasce: `meu-carrossel`

Só depois do primeiro carrossel aprovado. Estrutura:

```
meu-carrossel/
  SKILL.md
  assets/molde.html        o estilo dela, já com a ficha preenchida e os 8 slides
  references/render.md     a seção 4 deste manual, com o caminho do navegador DELA
```

O `SKILL.md` tem, no mínimo:
- `name: meu-carrossel` e uma `description` com os gatilhos dela ("monta a arte do carrossel", "faz os
  slides", "gera o carrossel com arte", "transforma esse texto em carrossel").
- O fluxo: pegar o texto aprovado (do motor ou colado) > copiar `assets/molde.html` para
  `meu-sistema/carrossel/<data>-<tema>/` > encaixar o texto > gerar os PNG > conferir > entregar os
  PNG, a legenda e o texto alternativo.
- As regras de texto da seção 3 e, se for o caso, as de conselho profissional.
- As fotos que ela costuma usar e onde ficam.
- O que nunca muda (cores, fontes, posição do título) e como pedir um estilo novo (referência nova,
  ajuste, aprovar, gravar).

Instale na pasta de skills (no Cowork, entregue também o `meu-carrossel.skill` para ela subir pelo
app) e acrescente ao `meu-motor`, logo após o carrossel em texto: "quer que eu já monte a arte?
(skill meu-carrossel)". Registre no `progresso.md`.
